import { Component, OnInit } from '@angular/core';
import * as d3 from 'd3';
import { Subscription } from 'rxjs';
import * as $ from 'jquery';
import { LasserviceService } from '../lasservice.service';
import { Schema } from '../schema';
import { HttpClient } from '@angular/common/http'

@Component({
  selector: 'app-d3js-line-chart',
  templateUrl: './d3js-line-chart.component.html',
  styleUrls: ['./d3js-line-chart.component.css']
})
export class D3jsLineChartComponent implements OnInit {

  processedData: any = [];
  topDepth: Number;
  constructor(private _raster: LasserviceService) { }
  ngOnInit() {

    this._raster.getData()
      .subscribe(data => {
        console.log(data);
        this.processedData = data;
        localStorage.setItem('graphData', JSON.stringify(this.processedData));
        console.log(this.processedData);
        // this.processedData.depth = data['depth'];
        // this.processedData.averageX = data['averageX'];
        // this.processedData.averageY = data['averageY'];
      })

    $(document).ready(function () {
      $('img').click(function (e) {
        var offset = $(this).offset();
        var X = (e.pageX - offset.left);
        var Y = (e.pageY - offset.top);
        var topLine = "<div style='position:absolute;width:100%;height:2px;background-color:red;top:" + Y + "px'></div>";
        $('.coord_cont').append(topLine);
        var datas = localStorage.getItem('graphData');

        var data = JSON.parse(datas);
        console.log('datas', data);
        for (var i = 0; i < data.length; i++) {
          var j = i + 1;
          if ((data[i].averageY) > (Y * 4.825) < (data[j].averageY) && j < data.length) {
            var yDiff = data[j].averageY - data[i].averageY;
            var depthDiff = data[j].depth - data[i].depth;
            var actualDepthDiff = ((Y * 4.825) - data[i].averageY) - 4184;
            var depthInter = (actualDepthDiff * depthDiff) / yDiff;
            this.topDepth = data[i].depth + depthInter;
            break;
          }
        }

        console.log(this.topDepth);
        $('#coord').text('X: ' +Math.round( X * 4.867 )+ ', Y: ' + Math.round(Y * 4.825 )+ ', Depth : ' + Math.round(this.topDepth));
        $('#coord').css('top',Y).css('position','absolute')


        console.log(data);
      });



    });

    $(document).ready(function () {
      $('img').on("mousemove", function (e) {
        var offset = $(this).offset();
        var X = (e.pageX - offset.left);
        var Y = (e.pageY - offset.top);
        $('.coord_cont').attr('title', 'X: ' + X * 4.867 + ', Y: ' + Y * 4.825 + ', Depth : ' + this.topDepth)
        // $('#coord').text('X: ' + X + ', Y: ' + Y);
        // $('#coord_cont').find('#top-line').css('top', Y + "px");
      });
    });


    $(function () {
      $('.star').click(function () {
        $(this).css('background', 'yellow');

      });
    });

  }


  // parseData(data) {
  //   var arr = [];
  //   for (var i in data.bpi) {
  //     arr.push({
  //       date: new Date(i), //date        
  //       value: +data.bpi[i] //convert string to number    
  //     });
  //   } return arr;
  // }

  // drawChart(parsedData) {

  //   let svgHeight = 400;
  //   let svgWidth = 600;

  //   let margin = { top: 20, right: 20, bottom: 30, left: 50 };
  //   let width = svgWidth - margin.left - margin.right;  //530
  //   let height = svgHeight - margin.top - margin.bottom; //350

  //   let svg = d3.select('svg')
  //     .attr('width', svgWidth)
  //     .attr('height', svgHeight)

  //   let g = svg.append('g')
  //     .attr('transform', 'translate(' + margin.left + ',' + margin.top + ')');

  //   let x = d3.scaleTime().rangeRound([0, width]);
  //   let y = d3.scaleLinear().rangeRound([height, 0]);


  //   var line = d3.line()
  //     .x(function (d) { return x(d.date) })
  //     .y(function (d) { return y(d.value) })
  //   x.domain(d3.extent(parsedData, function (d) { return d.date }));
  //   y.domain(d3.extent(parsedData, function (d) { return d.value }));


  //   g.append("g")
  //     .attr("transform", "translate(0," + height + ")")
  //     .call(d3.axisBottom(x))
  //     .select(".domain")
  //     .remove();

  //   g.append("g")
  //     .call(d3.axisLeft(y))
  //     .append("text")
  //     .attr("fill", "#000")
  //     .attr("transform", "rotate(-90)")
  //     .attr("y", 6)
  //     .attr("dy", "0.71em")
  //     .attr("text-anchor", "end")
  //     .text("Price ($)");

  //   g.append("path")
  //     .datum(this.parseData)
  //     .attr("fill", "none")
  //     .attr("stroke", "steelblue")
  //     .attr("stroke-linejoin", "round")
  //     .attr("stroke-linecap", "round")
  //     .attr("stroke-width", 1.5)
  //     .attr("d", line);


  // }


}
