import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { D3jsLineChartComponent } from './d3js-line-chart.component';

describe('D3jsLineChartComponent', () => {
  let component: D3jsLineChartComponent;
  let fixture: ComponentFixture<D3jsLineChartComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ D3jsLineChartComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(D3jsLineChartComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
