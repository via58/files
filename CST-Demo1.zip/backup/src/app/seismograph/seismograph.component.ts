import { Component, OnInit } from '@angular/core';
import { Chart } from 'angular-highcharts';
import { AngularWaitBarrier } from 'blocking-proxy/built/lib/angular_wait_barrier';
import { LasserviceService } from '../lasservice.service'

@Component({
  selector: 'app-seismograph',
  templateUrl: './seismograph.component.html',
  styleUrls: ['./seismograph.component.css']
})

export class SeismographComponent implements OnInit {
  adpoints: Number = 0;
  // dataPoints = {
  //   header: "",
  //   headerDescription: "",
  //   depthValue: "",
  //   listSpecficValue: ""
  // }
  dataPoints;
  constructor(private lasservice: LasserviceService) {
  }
  ngOnInit() {

  }
  // showData() {
  //   this.lasservice.getData('GRR').subscribe(
  //     data => {
  //       this.dataPoints = data;
  //     })

  // }
// chart = new Chart({

//   title: { text: 'Las Chart' },
//   credits: { enabled: false },
//   series: [
//     {
//       name: 'Gamma',
//       data: this.dataPoints.listSpecficValue,
//       lineWidth: 5,
//       type: 'spline'
//     } as Highcharts.SeriesSplineOptions]
// });
// add() {
//   this.chart.addPoint(Number(this.adpoints));
// }



}




