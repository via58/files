import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { SeismographComponent } from './seismograph.component';

describe('SeismographComponent', () => {
  let component: SeismographComponent;
  let fixture: ComponentFixture<SeismographComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ SeismographComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(SeismographComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
