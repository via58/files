import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { LargeheatgraphComponent } from './largeheatgraph.component';

describe('LargeheatgraphComponent', () => {
  let component: LargeheatgraphComponent;
  let fixture: ComponentFixture<LargeheatgraphComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ LargeheatgraphComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(LargeheatgraphComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
