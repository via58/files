import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http'
import { getLocaleDateFormat } from '@angular/common';
import { Schema } from './schema';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class LasserviceService {

  constructor(private _http: HttpClient) {

  }

  getData(): Observable<Schema> {
  //  const headers = new HttpHeaders({ 'Content-Type': 'application/json', 'Access-Control-Allow-Origin': "*" });
    return this._http.get<Schema>('http://localhost:8080/getraster');
    
  }
}
