import { TestBed } from '@angular/core/testing';

import { LasserviceService } from './lasservice.service';

describe('LasserviceService', () => {
  beforeEach(() => TestBed.configureTestingModule({}));

  it('should be created', () => {
    const service: LasserviceService = TestBed.get(LasserviceService);
    expect(service).toBeTruthy();
  });
});
