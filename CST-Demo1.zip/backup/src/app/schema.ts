export interface Schema {
    depth:Number,
    averageX:Number,
    averageY:Number
}
