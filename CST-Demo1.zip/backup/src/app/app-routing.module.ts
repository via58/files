import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { SeismographComponent } from './seismograph/seismograph.component';
import { LargeheatgraphComponent } from './largeheatgraph/largeheatgraph.component';
import { D3jsLineChartComponent } from './d3js-line-chart/d3js-line-chart.component';



const routes: Routes = [
  { path: 'seismograph', component: SeismographComponent },
  { path: 'heatgraph', component: LargeheatgraphComponent },
  { path: 'd3js', component: D3jsLineChartComponent }
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
export const routeComponents = [SeismographComponent, LargeheatgraphComponent, D3jsLineChartComponent]