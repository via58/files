// fs = require('fs');
// http = require('http');
// url = require('url');

// http.createServer(function(req, res){
//   var request = url.parse(req.url, true);
//   var action = request.pathname;
//      var img = fs.readFileSync('C:\\Dinesh\\VisualStudio\\CSTPreProcessing\\PNG\\sample1.png');
//      res.writeHead(200, {'Content-Type': 'image/gif' });
//      res.end(img, 'binary');
// }).listen(8081, '127.0.0.1');

const testFolder = './TiffFiles/';
const fs = require('fs');


fs.readdirSync(testFolder).forEach(file => {
  console.log(file);
});

var path = require('path');
var EXTENSION = '.txt';
var targetFiles = testFolder.filter(function(file) {
    return path.extname(file).toLowerCase() === EXTENSION;
});
console.log(targetFiles);