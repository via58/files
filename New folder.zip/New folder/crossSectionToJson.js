const fs = require('fs');


module.exports = { readFileAndConvertToJson(crossSectionName) {
    let filePath;
    if(crossSectionName == 'crossSection1'){
        filePath = fs.readFileSync('./CrossSectionFiles/crossSection1.txt');
    }else if(crossSectionName == 'crossSection2'){
        filePath = fs.readFileSync('./CrossSectionFiles/crossSection2.txt');
    }else if (crossSectionName == 'crossSection3'){
        filePath = fs.readFileSync('./CrossSectionFiles/crossSection3.txt');
    }else{
        return 'Pass valid topId or topId does not exists';
    }
    let output = JSON.parse(filePath);
    return output;
}
};