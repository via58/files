const express = require('express');
const bodyparser = require('body-parser');
const cors = require('cors')
var app = express();
var port = process.env.PORT || 8080;
app.use(bodyparser.json());
app.use(cors());

app.use((req, res, next) => {
    res.setHeader('Expires', '-1');
    res.set('Cache-Control', 'no-store, no-cache, must-revalidate, private');
    next();
  })

app.listen(port, function () {
    console.log('Application running in Localhost : ' + port);
})

app.get('/getCrossSectionDetails', async function (request, response) {
    var crossSection = require('./crossSectionToJson');
    var crossSectionName = request.query.crossSectionName;
    const logInfo = await crossSection.readFileAndConvertToJson(crossSectionName);
    response.send(logInfo);
})

app.get('/getCrossSection', async function (request,response){
    let result = {
        crossSectionNames : {}
    }
    var name = [];
    name[0]= 'crossSection1';
    name[1]= 'crossSection2';
    name[2]= 'crossSection3';
    response.send(result.crossSectionNames=name);
})

app.get('/getLASData', async function (request, response) {
    var lasTOJson = require('./lasToJSON');
    var uwiId = request.query.uwid;
    var curveName = request.query.curveName;
    const logInfo = await lasTOJson.readLasFileConvertToJson(uwiId,curveName);
    response.send(logInfo);
})

app.get('/getRasterData', async function(request, response){
    var uwiId = request.query.uwid;
    var rasterToJson = require('./rasterToJson');
    const logInfo = await rasterToJson.readRasterTextAndConvertToJson(uwiId);
    response.send(logInfo);
})

app.get('/getTiffFile', async function(request,response){
    var tiffFileName = request.query.tiffFileName;
    var tiffToPng = require('./fileConvert');
    const logInfo =Buffer.from(await tiffToPng.readTiffAndConvertToPng(tiffFileName),'base64');
    // console.log(logInfo);
    response.writeHead(200, {'Content-Type': 'image/gif' ,'Content-Length': logInfo.length});
    response.end(logInfo, 'binary');
    // response.send(logInfo);
})