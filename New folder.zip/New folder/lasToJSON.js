const Lasjs = require('las-js');
const result = {
    version: "",
    wellInformation : "",
    curveInformation : "",
    selectedCurve : "",
    curveColor : "",
    parameterInformation : "",
    curves : {}
   }

//    const colourCode = ['#ff1a1a','#cc0099','#9900ff','#3333cc','#0099ff','#006666','#339933',
//                         '#333300','#996633','#ff9900','#ffff00','#ff6666','#cccc00','#660033',
//                         '#666699','#00ff99','#000066','#993333','#cccc00','#ff6600','#0099cc'];

 module.exports = { async readLasFileConvertToJson(uwiId,curveName) {

    var fileVersion ="";
    var fileWellInformation = "";
    var fileCurveInformation ="";
    var fileParameterInformation = "";
    var fileCurveHeader = [];
    var final = [];
    var element = [];
    var curve = {};
    var filePath = '';
    var selectedCurveName='';
    var curveColors = '';
    if(uwiId != null && uwiId != ""){
    try {
        if(uwiId == 'US01003201370000' ){
            filePath = './LasFiles/US01003201370000.las';
        }else if (uwiId == 'US01013199980000'){
            filePath = './LasFiles/US01013199980000.las';
        }else if (uwiId == 'US01097200140000'){
            filePath = './LasFiles/US01097200140000.las';
        }else{
            return 'There is no data for selected UWI'
        }
    
        const myLas = new Lasjs(filePath);
        fileVersion = await myLas.version;
        fileWellInformation = await myLas.well;
        fileCurveInformation = await myLas.curve;
        fileParameterInformation = await myLas.param;
        fileCurveHeader = await myLas.header;
        var indexCount = 0;
        if(curveName != null && curveName != ""){
            selectedCurveName = curveName;
            curveColors = getRandomColor();
            for (let index = 1; index >= 0; index--) {
                if(index == 0){
                    final[indexCount] = await myLas.column(fileCurveHeader[index]);
                }else{
                    final[indexCount] = await myLas.column(curveName);
                }
                indexCount++;
            }
        }else{
            // console.log(JSON.parse(fileCurveInformation));
            if('GRR' in fileCurveInformation){
                selectedCurveName = 'GRR';
                curveColors = getRandomColor();
            for (let index = 1; index >= 0; index--) {
                    if(index==1){
                        final[indexCount] = await myLas.column('GRR');
                        }else{
                            final[indexCount] = await myLas.column(fileCurveHeader[index]);
                        }
                        indexCount++;
                }
            }
        }
        if(final.length>0){
        curve = final[0].map((col,i)=>final.map(row => row[i]));
        var icount = 0;
        for (let index = 0; index < curve.length; index++) {
             if(curve[index].includes(-999.25)){  
             }else{
                element[icount] = curve[index];
                icount++;
             }
        }
    }
        result.version = fileVersion;
        result.wellInformation = fileWellInformation;
        result.curveInformation = fileCurveInformation;
        result.parameterInformation = fileParameterInformation;
        result.selectedCurve = selectedCurveName;
        result.curveColor = curveColors;
        result.curves = element;

}catch (error) {
    console.log(error);
    }
}else{
    return "Pass valid uwiId or uwiId is missing" ;
}
    return result;
}
 };

 function getRandomColor() {
  var letters = '0123456789ABCDEF';
  var color = '#';
  for (var i = 0; i < 6; i++) {
    color += letters[Math.floor(Math.random() * 16)];
  }
  return color;
}