const fs = require('fs');
let input = fs.readFileSync('./RasterText.txt');
var i=1;
let splitted = input.toString().split("\n");
let result = {
    header : "",
    segment : [],
    data : []
}
let headerObj = {};
let segmentObj1 = {};
let segmentObj2 = [];
let dataObj=[];
let dataObj1=[];


module.exports = { async readRasterTextAndConvertToJson(uwid){
    if(uwiId != null && uwiId != ""){
    var headerCount = 0 ;
    var segmentCount =0;
    var dataCouont =0;
    var dataCount1 = 0;
    var segmentIndex =0;
    
    for (let index = 0; index < splitted.length; index++) {
        const element = splitted[index].split(':');
        if(headerCount == 0){
            headerObj[element[0]] = element[1].slice(0, -1);
            if(splitted[index].toString().indexOf("Reserved:")>-1){
                headerCount++;
            }
        }else if (splitted[index].startsWith('2,')){
            let dataString = splitted[index].slice(0,-1);
            dataString = dataString.split(',');
            for (let i = 2; i < dataString.length; i++) {
                dataObj[dataCouont] = dataString[i];
                dataCouont++;
            }
            dataObj1[dataCount1] = dataObj;
            dataObj = [];
            dataCount1++;
            dataCouont = 0;
        }else{
            if(splitted[index].toString().indexOf("Record Identifier: 1")>-1){
                segmentCount = segmentCount+2;
            }
            if(segmentCount == 2){
                segmentObj1[element[0]] = element[1].slice(0,-1);
                if(splitted[index].toString().indexOf("Reserved:")>-1){
                    segmentCount=segmentCount-1;
                }
            }
        }
        if(segmentCount == 1){
            if(splitted[index].toString() != "\r"){
                segmentObj2[segmentIndex] = segmentObj1;
                segmentObj1 = {};
                segmentIndex++;
                segmentCount--;
            }
        }
    }
}else{
    return "Pass valid uwiId or uwiId is missing" ;;
}
    result.data = dataObj1;
    result.header = headerObj;
    result.segment = segmentObj2;
    return result;
}
}


