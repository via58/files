const Jimp = require('jimp');
const fs = require('fs');

module.exports = {async readTiffAndConvertToPng(tiffFileName){
  var fileName = '';
 
  if(tiffFileName != null && tiffFileName != ''){
    if(tiffFileName == 'us50089200010000_4629856'){
      fileName = './TiffFiles/us50089200010000_4629856.tif'
    }else if (tiffFileName == 'us50089200040000_4632054'){
      fileName = './TiffFiles/us50089200040000_4632054.tif'
    }else if (tiffFileName =='us50089200060000_4636767'){
      fileName = './TiffFiles/us50089200060000_4636767.tif'
    }else{
      return 'There is no data for selected Tiff File Name';
    }  
      tiffToPngConversion(fileName,tiffFileName);
      for (let index = 0; index < 1000; index++) {
        if(index == 999){
          console.log(index);
          var result =   fs.readFileSync('./TiffFiles/'+tiffFileName+'.png');
        }
      }
      
  if(result != null && result != ''){
    return result;
  }else{
    return 'There is no data for selected Tiff File Name';
}
}else{
  return 'Must to pass Tiff File Name';
}
}
}

function tiffToPngConversion(fileName,tiffFileName) {
  Jimp.read(fileName, (err, res) => {
    if (err) throw err;
    res
      .write('./TiffFiles/'+tiffFileName+'.png'); // save
  });
}

function delay(time) {
  return new Promise(function(resolve) { 
      setTimeout(resolve, time)
  });
}

// function name(tiffFileName) {
//   setTimeout(function (res) {
//     console.log(fs.readFileSync('./TiffFiles/'+tiffFileName+'.png'));
//    return fs.readFileSync('./TiffFiles/'+tiffFileName+'.png'); 
// }, 1000);
// }