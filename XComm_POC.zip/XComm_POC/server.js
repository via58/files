﻿var http = require('http');

var express = require('express');
var app = express();
var bodyParser = require('body-parser');
var path = require('path');

app.use(bodyParser.json());
app.use(bodyParser.urlencoded({ extended: true }));

app.use('/public', express.static(__dirname + '/public'));
app.use('/images', express.static(__dirname + '/HTML_POC/images'));
app.use('/js', express.static(__dirname + '/HTML_POC/js'));
app.get('/HTML_POC*', function(req, res){
        res.sendFile(path.join(__dirname + '/HTML_POC/CSTTry.html'));
    });
app.get('*', function (req, res) {
        res.sendFile(path.join(__dirname + '/public/crossSection.html'));
    });

app.listen(8000);

console.log("Listening on port: 8000");