(function () {
    "use strict";
	var app = angular.module("crossSection", []);
	
    function crossSectionController(
        $scope, $window) {
			
			function _CSTEvents(){
				document.addEventListener('cstEvent', _handleCSTEvents, false);
			}

			function _handleCSTEvents(ev){
				if(ev.detail){
					var uniqueId = ev.detail.uniqueId;
					document.getElementById('parentLabel').innerText =ev.detail.message;
					//alert('CST passed info with unique id: ' + uniqueId + ' with msg: ' + ev.detail.message);
				}
			}
			
			$scope.actions={
				callCST: function(){
					var dataFromParent = {
						bubbles: true,
						detail: {
							uniqueId: (Math.floor(Math.random()*9000000) + 1000000),
							message: "Message from Parent"
						}
					};
					var ev = new CustomEvent('callerEvent', dataFromParent);
					document.getElementById('cstFrame').contentDocument.dispatchEvent(ev);
				}
			};
			
			function _init(){
				_CSTEvents();
			}
			_init();
		}
		crossSectionController.$inject = [
        '$scope',
        '$window'
		];
		app.controller('crossSection.crossSectionController', crossSectionController);
})();
