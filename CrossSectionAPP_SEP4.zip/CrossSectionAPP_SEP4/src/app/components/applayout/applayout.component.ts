import { Component, OnInit } from '@angular/core';
import { AppserviceService } from 'src/app/services/appservice.service';
import * as d3 from 'd3';
import { MAT_DATEPICKER_VALUE_ACCESSOR } from '@angular/material';

@Component({
  selector: 'app-applayout',
  templateUrl: './applayout.component.html',
  styleUrls: ['./applayout.component.scss']
})
export class ApplayoutComponent implements OnInit {

  constructor(private _http: AppserviceService) { }
  processedData: any = [];
  curveData: any = [];
  points: any = [];
  curveName: string = "GRR";
  wellCount: Number = 0;


  ngOnInit() {
    // Appending  SVG into div class cst-card-body-container  
    d3.select(".cst-card-body-container").style('overflow', 'auto');
    const svg = d3.select(".cst-card-body-container").append("svg")
      .attr("width", '100%').attr("height", '500')

    //creating order for loopong different well/track
    var order = 0;
    const dropData: any[] = ['Add Track', 'Export', 'Delete'];

    d3.json("http://localhost:8080/getCrossSectionDetails?crossSectionName=crossSection3")
      .then(function (data) {
        //console.log(data)
        console.log("crossSection Details   " + Object.keys(data.crossSectionDetails).length)
        const _crossSections = data.crossSectionDetails;
        var order = 0;
        console.log(data)
        //document.querySelector('.cst-card-header-badge').innerText = data.crossSection.totalWellCount;
        _crossSections.forEach(_well => {
          //   _well.forEach(curves => {

          ///Creating Well Name Frame _START

          const mainGroup = d3.select('svg').append('g').attr('class', 'mainGrp mainGrp' + _well[0].UWI).attr('transform', 'translate(' + ((order * 290) + 10) + ', 10)');
          const formgrp = mainGroup.append('g')
          const formgrpcontainer = formgrp.append('foreignObject')
            .attr('class', 'wellgroup wellgroup' + _well[0].UWI)
            .attr('id', 'foreignObject' + _well[0].UWI)
          const WellNameDiv = formgrpcontainer.append('xhtml:div')
            .attr('class', 'well-info-name')
            .html(_well[0].wellName)
            .append('div')
            .attr('class', 'float-right')
            .append('i')
            .attr('class', 'fa fa-ellipsis-h')

            .on('click', function (d) {
              console.log(document.querySelectorAll('.addtrack').length)
              const trackLength = document.querySelectorAll('.addtrack').length;
              if (trackLength == 0) {
                const div = d3.select('body').append('div').attr('class', 'addtrack')

                div.selectAll('ul')
                  .data(dropData)
                  .enter()
                  .append('ul')
                  .attr('id', 'mainGrp' + _well[0].UWI)
                  .on('click', function (d) {
                    console.log(d3.select(this).node().id) //Add Track Api
                    var trackId = d3.select(this).node().id;
                    var referenceGroup = document.querySelector('.' + trackId);
                    referenceGroup.after(document.createElement('g'))
                    // d3.select('svg').insert( referenceGroup, '#first + *')
                  })
                  .append('li')
                  .text(function (d) { return d })
                d3.select('.addtrack').style('display', 'block')
                  .style("left", (d3.event.pageX - 153) + "px")
                  .style("top", (d3.event.pageY + 7) + "px");
              }
              else {
                d3.selectAll('.addtrack').remove();
              }
            });
          ////Creating Well Name Frame  -END

          ////Creating Radio and DropDown Frame  -START
          //Adding DIV inside this div ,3 div will be appended for radioLas ,radioRaster,LasDropDown
          const WellInfoproductDiv = d3.select('#foreignObject' + _well[0].UWI).append('xhtml:div')
            .attr('class', 'well-info-product')
            .attr('id', 'well-info-product' + _well[0].UWI); // Need to change when working for subtrack 

          //Creating RadioLas -START
          const LasRadioDiv = WellInfoproductDiv.append('div')
            .attr('class', 'custom-control custom-radio custom-control-inline')

          const LasBtn = LasRadioDiv.append('input')
            .attr('class', 'custom-control-input')
            .attr('type', 'radio')
            .attr('name', 'inlineRadioOptions' + order)
            .attr('id', 'inlineRadioLas' + order)
            .attr('data-id', 'Las' + order)
            .attr('value', 'LAS' + _well[0].UWI + _well[0].curveName)
            .on('change', function (d) {
              console.log('button changed to ' + this.value);
              if (this.value == "LAS" + _well[0].UWI + _well[0].curveName) {
                d3.select(`.mainGrp${_well[0].UWI} .rasterGrp`).style('display', 'none');
                d3.select(`.mainGrp${_well[0].UWI} .loader`).style('display', 'block');

                drawPath(_well[0].UWI, _well[0].curveName);
                if (_well[0].curveNames) {
                   document.querySelector('.lasdropdownUS01097200140000').selectedIndex = _well[0].curveNames.indexOf(_well[0].curveName)
                 // d3.select('.lasdropdownUS01097200140000').property(_well[0].curveNames.indexOf(_well[0].curveName)); 

                } else {
                  d3.select(`.mainGrp${_well[0].UWI} .loader`).style('display', 'none');
                }
                //console.log(_well[0].curveNames);
                d3.select('.chartGrp' + _well[0].UWI + _well[0].curveName).style('display', 'block');
                d3.select('.rasterGrp' + _well[0].UWI + _well[0].curveName).style('display', 'none');
                d3.select('.lasdropdown' + _well[0].UWI).style('display', 'block');
                d3.selectAll('.wellgroup' + _well[0].UWI).style('height', '130px');
              }
              else if (this.value == "Raster" + _well[0].UWI + _well[0].curveName) {
                d3.select('.chartGrp' + _well[0].UWI + _well[0].curveName).style('display', 'none');
                d3.select('.rasterGrp' + _well[0].UWI + _well[0].curveName).style('display', 'block');
                d3.select('.lasdropdown' + _well[0].UWI).style('display', 'none');
                d3.selectAll('.wellgroup' + _well[0].UWI).style('height', '84px')
              }
            });


          const laslabel = LasRadioDiv.append('label')
            .attr('class', 'custom-control-label')
            .attr('for', 'inlineRadioLas' + order)
            .html('LAS');


          //Creating RadioLas -END

          //Creating RadioRaster -START
          const RasterRadioDiv = WellInfoproductDiv.append('div')
            .attr('class', 'custom-control custom-radio custom-control-inline')


          const RasterBtn = RasterRadioDiv.append('input')
            .attr('class', 'custom-control-input')
            .attr('type', 'radio')
            .attr('name', 'inlineRadioOptions' + order)
            .attr('id', 'inlineRadioRaster' + order)
            .attr('data-id', 'raster' + order)
            .attr('value', 'Raster' + _well[0].UWI + _well[0].curveName)
            .attr('checked', 'checked')
            .on('change', function (d) {
              if (this.value == "Raster" + _well[0].UWI + _well[0].curveName) {
                d3.select(`.mainGrp${_well[0].UWI} .chartGrp`).remove();
                d3.select(`.mainGrp${_well[0].UWI} .rasterGrp`).style('display', 'block');

                console.log("Raster" + _well[0].UWI + _well[0].curveName)
                d3.select('.chartGrp' + _well[0].UWI + _well[0].curveName).style('display', 'none');
                d3.select('.rasterGrp' + _well[0].UWI + _well[0].curveName).style('display', 'block');
                d3.select('.lasdropdown' + _well[0].UWI).style('display', 'none');
                d3.selectAll('.wellgroup' + _well[0].UWI).style('height', '84px')

              }
              else if (this.value == "LAS" + _well[0].UWI + _well[0].curveName) {
                d3.select('.chartGrp' + _well[0].UWI + _well[0].curveName).style('display', 'block');
                d3.select('.rasterGrp' + _well[0].UWI + _well[0].curveName).style('display', 'none');
                d3.select('.lasdropdown' + _well[0].UWI).style('display', 'show');
                d3.selectAll('.wellgroup' + _well[0].UWI).style('height', '130px')


              }
            });
          const Rasterlabel = RasterRadioDiv.append('label')
            .attr('class', 'custom-control-label')
            .attr('for', 'inlineRadioRaster' + order)
            .html('Raster');

          //Creating RadioRaster -END

          //Creating LasDropDown -START
          const LasDropDown = WellInfoproductDiv.append('div')
            .attr('class', 'form-group')
            .append('select')
            .attr('class', 'form-control lasdropdown' + _well[0].UWI)
            .style('display', 'none')
          if (_well[0].curveNames) {
            //.append("option")
            LasDropDown.selectAll("option")
              .data(_well[0].curveNames)
              .enter()
              .append("option")
              .attr("value", function (d) { return d })
              .text(function (d) { return d })

          } else {
            LasDropDown
              .append("option")
              .attr("value", "No Data Found")
              .text("No Data Found")
          }

          //Creating RadioDropDown -END
          LasDropDown.on('change', function (d) {
            console.log(this.value)
            this.curveName = this.value;
            d3.select(`.mainGrp${_well[0].UWI} .loader`).style('display', 'block');
            d3.select(`.mainGrp${_well[0].UWI} .chartGrp`).remove();
            drawPath(_well[0].UWI, this.value);
            setTimeout(function () {
              d3.select('.chartGrp' + _well[0].UWI + this.value).style('display', 'block');
            }, 5000)

            console.log('.chartGrp' + _well[0].UWI + this.value)
          })
          ////Creating Radio and DropDown Frame  -END
          //Creating Loader inside main Grp -START
          const loaderGrp = d3.select('.mainGrp' + _well[0].UWI).append('g').attr('class', 'loader').attr('display', 'none').attr('transform', 'translate(0,130)');
          loaderGrp.append('foreignObject').attr('width', '250')
            .attr('height', '150')

            .append('xhtml:div')
            .attr('class', 'fa-4x')
            .append('i')
            .attr('class', 'fas fa fa-spinner fa-spin')
          //Creating Loader inside main Grp -END

          const rasterGroup = mainGroup.append('g').attr('class', 'rasterGrp rasterGrp' + _well[0].UWI.UWI + _well[0].UWI.curveName).attr('transform', 'translate(0,100)');
          var rasterImg = rasterGroup.append('foreignObject')
            .attr('width', '250')
            .attr('height', '380')

          const rasterDiv = rasterImg.append('xhtml:div')
            .attr('class', 'rastergrp imggrp')
            .append('img')
            .attr('src', 'http://localhost:8080/getTiffFile?tiffFileName=us50089200010000_4629856')
            .attr('class', 'imgsize')

          //drawPath(_well[0].UWI, _well[0].curveName);
          ///Creating Chart Group  -START
          function drawPath(uwid, curveName) {
            if (_well[0].rasterLasFlag == 'Las') {

              d3.json("http://localhost:8080/getLASData?uwid=" + uwid + "&curveName=" + curveName).then(function (data) {
                console.log(curveName + "AND" + uwid)
                const xScale = d3.scaleLinear().domain(d3.extent(data.curves, function (d) { return d[0] })).nice().range([0, 210]); // Xaxis Scale
                const yScale = d3.scaleLinear().domain([d3.max(data.curves, function (d) { return d[1] }), d3.min(data.curves, function (d) { return d[1] })]).range([300, 0]); // Yaxis Scale

                const xAxis = d3.axisTop(xScale).tickSize(-300).ticks(5); // Xaxis 
                const yAxis = d3.axisLeft(yScale).tickSize(-210).ticks(5); // Y axis 
                const line = d3.line()
                  .x(function (d) { return xScale(d[0]) })
                  .y(function (d) { return yScale(d[1]) })
                  .curve(d3.curveCardinal) // Cardinal graph generater
                const grp = d3.select(`.mainGrp${uwid}`);
                console.log(`.mainGrp${uwid}`);
                const chartGroup = grp.append('g').attr('class', 'chartGrp chartGrp' + uwid + curveName).attr('transform', 'translate(30 ,160)');
                // const cgrp = d3.select('chartGrp' +uwid + curveName);
                // console.log(cgrp);
                //const rastergrp = grp.append('g').attr('class', 'rasterGrp' + _well[0].UWI.UWI + _well[0].UWI.curveName).attr('transform', 'translate(' + ((order * 290)) + ',100)');
                const grpXAxis = chartGroup.append('g').attr('class', 'axisred').attr('transform', 'translate(7,0)');
                grpXAxis.call(xAxis);
                const grpYAxis = chartGroup.append('g').attr('class', 'axisred').attr('transform', 'translate(7,0)');
                grpYAxis.call(yAxis);

                d3.select(`.mainGrp${_well[0].UWI} .loader`).style('display', 'none');
                /// Drawing Path by sending Data points 
                chartGroup.append("path").attr('transform', 'translate(11,2)')
                  .attr("d", line(data.curves))
                  .attr('class', 'lasgrp')
                  .attr('fill', 'none')
                  .attr('stroke-width', 1)
                  .attr('stroke', data.curveColor)
              })
            }
          }




          ///Creating Chart Group -END




          //  drawD3Curve(_well[0]);
          //   });
          order = order + 1;
        });
      })
      .catch(console.error());

    function getDropDownData(_uwid, _curveName): Promise<any> {
      var list = d3.json("http://localhost:8080/getLASData?uwid=" + _uwid + "&curveName=" + _curveName).then(function (data) {
        console.log(data)
        return Object.keys(data.curveInformation);

      }).catch(function (error) {
        console.log(error)
      })
      return list;
    }






    function drawD3Curve(_currentWellInfo) {
      console.log(_currentWellInfo)




      const formgrpproduct = d3.select('.vijay').append('xhtml:div')
        .attr('class', 'well-info-product')
        .attr('id', 'LAS' + _currentWellInfo.UWI + _currentWellInfo.curveName);

      const productgrp = formgrpproduct.append('div')
        .attr('class', 'custom-control custom-radio custom-control-inline')
      // .attr('id', 'LAS' + _currentWellInfo.UWI + _currentWellInfo.curveName);

      const lasgrp = productgrp.append('input')
        .attr('class', 'custom-control-input')
        .attr('type', 'radio')
        .attr('name', 'inlineRadioOptions' + order)
        .attr('id', 'inlineRadioLas' + order)
        .attr('data-id', 'Las' + order)
        .attr('value', 'LAS' + _currentWellInfo.UWI + _currentWellInfo.curveName)
        .on('change', function (d) {
          console.log('button changed to ' + this.value);
          if (this.value == "LAS" + _currentWellInfo.UWI + _currentWellInfo.curveName) {
            d3.select('.chartGrp' + _currentWellInfo.UWI + _currentWellInfo.curveName).style('display', 'block');
            d3.select('.rasterGrp' + _currentWellInfo.UWI + _currentWellInfo.curveName).style('display', 'none');
            d3.select('.lasdropdown').style('display', 'block');
          }
          else if (this.value == "Raster" + _currentWellInfo.UWI + _currentWellInfo.curveName) {
            d3.select('.chartGrp' + _currentWellInfo.UWI + _currentWellInfo.curveName).style('display', 'none');
            d3.select('.rasterGrp' + _currentWellInfo.UWI + _currentWellInfo.curveName).style('display', 'block');
            d3.select('.lasdropdown').style('display', 'none');
          }
        });

      const lasgrplabel = productgrp.append('label')
        .attr('class', 'custom-control-label')
        .attr('for', 'inlineRadioLas' + order)
        .html('LAS');

      const productgrp1 = formgrpproduct.append('div')
        .attr('class', 'custom-control custom-radio custom-control-inline');


      const rastergrp = productgrp1.append('input')
        .attr('class', 'custom-control-input')
        .attr('type', 'radio')
        .attr('name', 'inlineRadioOptions' + order)
        .attr('id', 'inlineRadioRaster' + order)
        .attr('data-id', 'raster' + order)
        .attr('value', 'Raster' + _currentWellInfo.UWI + _currentWellInfo.curveName)
        .attr('checked', 'checked')
        .on('change', function (d) {
          if (this.value == "Raster" + _currentWellInfo.UWI + _currentWellInfo.curveName) {
            console.log("Raster" + _currentWellInfo.UWI + _currentWellInfo.curveName)
            d3.select('.chartGrp' + _currentWellInfo.UWI + _currentWellInfo.curveName).style('display', 'none');
            d3.select('.rasterGrp' + _currentWellInfo.UWI + _currentWellInfo.curveName).style('display', 'block');
            d3.select('.lasdropdown').style('display', 'none');

          }
          else if (this.value == "LAS" + _currentWellInfo.UWI + _currentWellInfo.curveName) {
            d3.select('.chartGrp' + _currentWellInfo.UWI + _currentWellInfo.curveName).style('display', 'block');
            d3.select('.rasterGrp' + _currentWellInfo.UWI + _currentWellInfo.curveName).style('display', 'none');
            d3.select('.lasdropdown').style('display', 'show');


          }
        });
      const rastergrplabel = productgrp1.append('label')
        .attr('class', 'custom-control-label')
        .attr('for', 'inlineRadioRaster' + order)
        .html('Raster');


      if (_currentWellInfo.rasterLasFlag == 'Las') {

        console.log("http://localhost:8080/getLASData?uwid=" + _currentWellInfo.UWI + "&curveName=" + _currentWellInfo.curveName);
        d3.json("http://localhost:8080/getLASData?uwid=" + _currentWellInfo.UWI + "&curveName=" + _currentWellInfo.curveName).then(function (data) {
          // console.log(data)
          const xScale = d3.scaleLinear().domain([0, d3.max(data.curves, function (d) { return d[0] })]).range([0, 210]); // Xaxis Scale
          const yScale = d3.scaleLinear().domain([d3.max(data.curves, function (d) { return d[1] }), d3.min(data.curves, function (d) { return d[1] })]).range([300, 0]); // Yaxis Scale

          const xAxis = d3.axisTop(xScale).ticks(5); // Xaxis 
          const yAxis = d3.axisLeft(yScale).ticks(5); // Y axis 
          const line = d3.line()
            .x(function (d) { return xScale(d[0]) })
            .y(function (d) { return yScale(d[1]) })
            .curve(d3.curveCardinal) // Cardinal graph generater
          const grp = d3.select(`#${_currentWellInfo.UWI}`);
          console.log(grp);
          const shapegrp = grp.append('g').attr('class', 'chartGrp' + _currentWellInfo.UWI + _currentWellInfo.curveName).attr('transform', 'translate(30 ,160)').style('display', 'none');
          const rastergrp = grp.append('g').attr('class', 'rasterGrp' + _currentWellInfo.UWI + _currentWellInfo.curveName).attr('transform', 'translate(' + ((order * 290)) + ',100)');
          const grpXAxis = shapegrp.append('g').attr('class', 'axisred').attr('transform', 'translate(7,0)');
          grpXAxis.call(xAxis);
          const grpYAxis = shapegrp.append('g').attr('class', 'axisred').attr('transform', 'translate(7,0)');
          grpYAxis.call(yAxis);
          const curveColor = '#ff6600';

          shapegrp.append("path").attr('transform', 'translate(11,2)')
            .attr("d", line(data.curves))
            .attr('class', 'lasgrp')
            .attr('fill', 'none')

            .attr('stroke-width', 1)
            .attr('stroke', data.curveColor)


          var rasterImg = rastergrp.append('foreignObject')
            .attr('width', '250')
            .attr('height', '400')
            .attr('class', 'rastergrp')
            .style('display', 'none');

          const rasterDiv = rasterImg.append('xhtml:div')
            .attr('class', 'rastergrp')
            .append('img')
            .attr('src', 'http://localhost:8080/getTiffFile?tiffFileName=us50089200010000_4629856')
            .attr('class', 'imgsize')

          const projectlist = d3.select('#' + 'LAS' + _currentWellInfo.UWI + _currentWellInfo.curveName).append('div')
            .attr('class', 'form-group')
            .append('select')
            .attr('class', 'form-control lasdropdown')
            .style('display', 'none')
          projectlist.selectAll("option")
            .data(Object.keys(data.curveInformation))
            .enter()
            .append("option")
            .attr("value", function (d) { if (d !== "DEPT") { return d } })
            .text(function (d) { if (d !== "DEPT") { return d } })


        })
      }




      order = order + 1;

    }
    function drawRaster() {

    }
  }























































  // private async drawChart(data) {


  //   const points: any[] = []

  //   const width = 600, height = 400;
  //   // d3.select(".cst-card-body-container").style('overflow', 'auto');
  //   // const svg = d3.select(".cst-card-body-container").append("svg")
  //   //   .attr("width", '100%').attr("height", '500');

  //   this.productType(data);

  //   await this.drawCurve();


  //   //   await this.drawAxisandPath(data);
  // }

  // private async productType(data) {

  //   const points: any[] = [];
  //   //data.crossSection.totalWellCount
  //   for (var t = 0; t < 1; t++) {


  //     const grp = d3.select('svg').append('g').attr('class', 'mainGrp').attr('transform', 'translate(' + ((t * 290)) + ', 0)');
  //     const formgrp = grp.append('g')
  //     const formgrpcontainer = formgrp.append('foreignObject')
  //       .attr('width', '250')
  //       .attr('height', '150');
  //     const formgrptitle = formgrpcontainer.append('xhtml:div')
  //       .attr('class', 'well-info-name')
  //       .html(data.crossSectionDetails[0][0].wellName)
  //       .append('div')
  //       .attr('class', 'float-right')
  //       .append('i')
  //       .attr('class', 'fa fa-ellipsis-h');
  //     const formgrpproduct = formgrpcontainer.append('xhtml:div')
  //       .attr('class', 'well-info-product');

  //     const productgrp = formgrpproduct.append('div')
  //       .attr('class', 'custom-control custom-radio custom-control-inline');
  //     const lasgrp = productgrp.append('input')
  //       .attr('class', 'custom-control-input')
  //       .attr('type', 'radio')
  //       .attr('name', 'inlineRadioOptions' + t)
  //       .attr('id', 'inlineRadio1')

  //       .attr('data-id', t)
  //       .attr('value', 'LAS')
  //       .on('change', function (d) {
  //         console.log('button changed to ' + this.value);
  //         if (this.value == "LAS") {


  //           d3.select('.chartGrp').style('display', 'block');
  //           d3.select('.rasterGrp').style('display', 'none');
  //           d3.select('.lasdropdown').style('display', 'block');


  //         }
  //         else {
  //           d3.select('.chartGrp').style('display', 'none');
  //           d3.select('.rasterGrp').style('display', 'block');
  //           d3.select('.lasdropdown').style('display', 'none');


  //         }
  //       });

  //     const lasgrplabel = productgrp.append('label')
  //       .attr('class', 'custom-control-label')
  //       .attr('for', 'inlineRadio1')
  //       .html('LAS');



  //     const productgrp1 = formgrpproduct.append('div')
  //       .attr('class', 'custom-control custom-radio custom-control-inline');
  //     const rastergrp = productgrp1.append('input')
  //       .attr('class', 'custom-control-input')
  //       .attr('type', 'radio')
  //       .attr('name', 'inlineRadioOptions' + t)
  //       .attr('id', 'inlineRadio2')
  //       .attr('checked', 'checked')
  //       .attr('data-id', t)
  //       .attr('value', 'Raster')
  //       .on('change', function (d) {
  //         if (this.value == "Raster") {
  //           d3.select('.chartGrp').style('display', 'none');
  //           d3.select('.rasterGrp').style('display', 'block');
  //           d3.select('.lasdropdown').style('display', 'none');

  //         }
  //         else {
  //           d3.select('.chartGrp').style('display', 'block');
  //           d3.select('.rasterGrp').style('display', 'none');
  //           d3.select('.lasdropdown').style('display', 'show');


  //         }
  //       });
  //     //data.crossSectionDetails[0][0].UWI,data.crossSectionDetails[0][0].curveName

  //     //       this.drawCurve();

  //     this.curveData = JSON.parse(localStorage.getItem('curveData'))
  //     //console.log(this.curveData)
  //     //this.points = this.curveData.curves;
  //     const rastergrplabel = productgrp1.append('label')
  //       .attr('class', 'custom-control-label')
  //       .attr('for', 'inlineRadio2')
  //       .html('Raster');

  //     const projectlist = formgrpproduct.append('div')
  //       .attr('class', 'form-group')
  //       .append('select')
  //       .attr('class', 'form-control lasdropdown')
  //       .style('display', 'none')
  //     projectlist.selectAll("option")
  //       .data(Object.keys(this.curveData.curveInformation))
  //       .enter()
  //       .append("option")
  //       .attr("value", function (d) { if (d !== "DEPT") { return d } })
  //       .text(function (d) { if (d !== "DEPT") { return d } })
  //     projectlist.on('change', function (d) {
  //       // console.log(this.value)
  //       this.curveName = this.value;

  //       d3.select('.chartGrp').remove();

  //       // this._http.getCrossSectionData("US01003201370000", this.value)
  //       //   .subscribe(
  //       //   data => {
  //       //     console.log(data)

  //       //     //console.log(this.points)
  //       //     localStorage.setItem('curveData', JSON.stringify(data))

  //       //   })

  //       d3.json("http://localhost:8080/getLASData?uwid=US01003201370000&curveName=" + this.value).then(function (data) {
  //         // console.log(data)

  //         const xScale = d3.scaleLinear().domain([0, d3.max(data.curves, function (d) { return d[0] })]).range([0, 210]); // Xaxis Scale
  //         const yScale = d3.scaleLinear().domain([d3.max(data.curves, function (d) { return d[1] }), d3.min(data.curves, function (d) { return d[1] })]).range([300, 0]); // Yaxis Scale

  //         const xAxis = d3.axisTop(xScale).ticks(5); // Xaxis 
  //         const yAxis = d3.axisLeft(yScale).ticks(5); // Y axis 
  //         const line = d3.line()
  //           .x(function (d) { return xScale(d[0]) })
  //           .y(function (d) { return yScale(d[1]) })
  //           .curve(d3.curveCardinal) // Cardinal graph generater
  //         const grp = d3.select('.mainGrp');
  //         const shapegrp = grp.append('g').attr('class', 'chartGrp').attr('transform', 'translate(30,160)');
  //         const rastergrp = grp.append('g').attr('class', 'rasterGrp').attr('transform', 'translate(0,100)');
  //         const grpXAxis = shapegrp.append('g').attr('class', 'axisred').attr('transform', 'translate(7,0)');
  //         grpXAxis.call(xAxis);
  //         const grpYAxis = shapegrp.append('g').attr('class', 'axisred').attr('transform', 'translate(7,0)');
  //         grpYAxis.call(yAxis);
  //         const curveColor = '#ff6600';
  //         // if(this.value !=='GRR'){
  //         //   const curveColor = '#ff6600';
  //         // }
  //         shapegrp.append("path").attr('transform', 'translate(11,2)')
  //           .attr("d", line(data.curves))
  //           .attr('class', 'lasgrp')
  //           .attr('fill', 'none')
  //           .attr('stroke-width', 1)
  //           .attr('stroke', data.curveColor)




  //         var rasterImg = rastergrp.append('foreignObject')
  //           .attr('width', '250')
  //           .attr('height', '400')
  //           .attr('class', 'rastergrp')
  //           .style('display', 'none');

  //         const rasterDiv = rasterImg.append('xhtml:div')
  //           .attr('class', 'rastergrp')
  //           .append('img')
  //           .attr('src', 'http://localhost:8080/getTiffFile?tiffFileName=us50089200010000_4629856')
  //           .attr('class', 'imgsize')

  //         // shapegrp.append('rect')
  //         //   .attr('width', '220')
  //         //   .attr('class', 'rastergrp')
  //         //   .attr('height', '300')
  //         //   .attr('fill', 'blue')
  //         //   .style('display', 'none');
  //         shapegrp.on('click', function (e) {
  //         })

  //       })


  //     })

  //   }
  // }

  // private async drawCurve() {

  //   this._http.getCrossSectionData(this.uwid, this.curveName)
  //     .subscribe(
  //       data => {
  //         // console.log(data)

  //         //console.log(this.points)
  //         localStorage.setItem('curveData', JSON.stringify(data))

  //       })
  //   this.curveData = JSON.parse(localStorage.getItem('curveData'))
  //   this.points = this.curveData.curves;

  //   const xScale = d3.scaleLinear().domain([0, d3.max(this.points, function (d) { return d[0] })]).range([0, 210]); // Xaxis Scale
  //   const yScale = d3.scaleLinear().domain([d3.max(this.points, function (d) { return d[1] }), d3.min(this.points, function (d) { return d[1] })]).range([300, 0]); // Yaxis Scale

  //   const xAxis = d3.axisTop(xScale).ticks(5); // Xaxis 
  //   const yAxis = d3.axisLeft(yScale).ticks(5); // Y axis 
  //   const line = d3.line()
  //     .x(function (d) { return xScale(d[0]) })
  //     .y(function (d) { return yScale(d[1]) })
  //     .curve(d3.curveCardinal) // Cardinal graph generater
  //   const grp = d3.select('.mainGrp');
  //   const shapegrp = grp.append('g').attr('class', 'chartGrp').style('display', 'none').attr('transform', 'translate(30,160)');
  //   const rastergrp = grp.append('g').attr('class', 'rasterGrp').attr('transform', 'translate(0,100)');
  //   const grpXAxis = shapegrp.append('g').attr('class', 'axisred').attr('transform', 'translate(7,0)');
  //   grpXAxis.call(xAxis);
  //   const grpYAxis = shapegrp.append('g').attr('class', 'axisred').attr('transform', 'translate(7,0)');
  //   grpYAxis.call(yAxis);
  //   shapegrp.append("path").attr('class', 'line').attr('transform', 'translate(11,2)')
  //     .attr("d", line(this.points))
  //     .attr('class', 'lasgrp')
  //     .attr('fill', 'none')
  //     .attr('stroke-width', 1)
  //     .attr('stroke', '#3496f7')
  //   //.attr('stroke', function(){ return "hsl (" +Math.random() *360 +",100%,50%)" })
  //   // document.querySelector('.lasdropdown').selectedIndex = "8";

  //   var rasterImg = rastergrp.append('foreignObject')
  //     .attr('width', '250')
  //     .attr('height', '500')
  //     .attr('class', 'rastergrp ');
  //   const rasterDiv = rasterImg.append('xhtml:div')
  //     .attr('class', 'imggrp scrollbar scrollbar-success')
  //     .append('img')
  //     .attr('src', 'http://localhost:8080/getTiffFile?tiffFileName=us50089200010000_4629856')
  //     .attr('class', 'imgsize')



  //   // shapegrp.append('rect')
  //   //   .attr('width', '220')
  //   //   .attr('class', 'rastergrp')
  //   //   .attr('height', '300')
  //   //   .attr('fill', 'blue')
  //   //   .style('display', 'none');
  //   shapegrp.on('click', function (e) {
  //   })

  // }

}
