const Lasjs = require('las-js');
const express = require('express');
const bodyparser = require('body-parser');
const rasterObject = require('./raster.json');
const cors = require('cors');

var app = express();
app.use(cors());

var port = process.env.PORT || 8080;
app.use(bodyparser.json());
const logData = "";
const result = {
    header: "",
    headerDescription: "",
    depthValue: "",
    listSpecficValue: "",


}

async function read(desiredParams) {
    var lasHeaders = "";

    try {
        const myLas = new Lasjs('./OldOcean.las');
        const data = await myLas.data;
        const dataStripped = await myLas.dataStripped;
        lasHeaders = await myLas.header;
        result.header = lasHeaders;

        const headerDesc = await myLas.headerAndDescr;
        result.headerDescription = headerDesc;

        if (desiredParams != "") {
            const valuesList = await myLas.column(desiredParams);
            result.listSpecficValue = valuesList;
        }
        const dValue = await myLas.column('DEPT');
        if (dValue != "") {

            result.depthValue = dValue;
        }
        // const name = await myLas.WRAP.descr;
        console.log(`name ${name}`);
    } catch (error) {
        console.log(error);
    }
    return result;
}


app.get('/headerInfo', async function (request, response) {

    const logInfo = await read("");
    response.send(logInfo);
})


app.get('/dataStripped/:_parameter', async function (request, response) {

    const requestParam = request.params._parameter;
    const result = await read(requestParam);
    console.log(requestParam);
    response.send(result);
})

app.get('/getraster', function (request, response) {


    var numberArray = [];
    rasterObject[0].data.forEach(element => {
        var avgx = Math.round((element[3] + element[5] + element[7] + element[9] + element[11]) / 5);
        var avgy = Math.round((element[4] + element[6] + element[8] + element[10] + element[12]) / 5);
        numberArray.push({
            depth: element[2],
            averageX: avgx,
            averageY: avgy
        });
    });

    response.json(numberArray);
})
app.listen(port, function () {
    console.log('Application running in Localhost : ' + port);
})



