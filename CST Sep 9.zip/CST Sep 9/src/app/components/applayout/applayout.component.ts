import { Component, OnInit } from '@angular/core';
import { AppserviceService } from 'src/app/services/appservice.service';
import * as d3 from 'd3';
import PerfectScrollbar from 'perfect-scrollbar';

@Component({
  selector: 'app-applayout',
  templateUrl: './applayout.component.html',
  styleUrls: ['./applayout.component.scss']
})
export class ApplayoutComponent implements OnInit {

  constructor(private _http: AppserviceService) { }
  processedData: any = [];
  curveData: any = [];
  points: any = [];
  curveName: string = "GRR";
  wellCount: Number = 0;
  

  ngOnInit() {
    // Appending  SVG into div class cst-card-body-container  
    d3.select(".cst-card-body-container");
    const svg = d3.select(".cst-card-body-container").append("svg")
      .attr("width", '2000').attr("height", '500')

      // const containers = document.querySelector('#cst-card-body-container');      
      // const ps = new PerfectScrollbar('#cst-card-body-container', {
      //   wheelSpeed: 2,
      //   wheelPropagation: true,
      //   minScrollbarLength: 20
      // });

    //creating order for loopong different well/track
    var order = 0;
    var trackId = 0;
    var trackorder = 0;
    const dropData: any[] = ['Add Track', 'Export', 'Delete'];

    d3.json("http://localhost:8080/getCrossSectionDetails?crossSectionName=crossSection3")
      .then(function (data) {
        //console.log(data)
        console.log("crossSection Details   " + Object.keys(data.crossSectionDetails).length)
        const _crossSections = data.crossSectionDetails;
        var order = 0;
        console.log(data)
        //document.querySelector('.cst-card-header-badge').innerText = data.crossSection.totalWellCount;
        _crossSections.forEach(_well => {
          // d3.select('svg').append('g').attr('class', 'mainGrp mainGrp' + order).attr('transform', 'translate(' + ((order * 290) + 10) + ', 10)')
          trackorder = 0;
          _well.forEach(curves => {
            var mainGroup = null;
            console.log('.mainGrp' + curves.UWI + "1")
            ///Creating Well Name Frame _START
            console.log(document.querySelectorAll('.mainGrp' + curves.UWI + "1").length);
            if (document.querySelectorAll('.mainGrp' + curves.UWI + "1").length == 0) {
              mainGroup = d3.select('svg').append('g').attr('class', 'mainGrp mainGrp' + curves.UWI + curves.trackorder).attr('transform', 'translate(' + ((order * 290) + 10) + ', 10)').append('g').attr('transform', 'translate( ' + ((trackorder * 290) + 10) + ', 10)').attr('class', 'uniq uniq' + curves.UWI + curves.trackorder)

            } else {
              mainGroup = d3.select('.mainGrp' + curves.UWI + "1").append('g').attr('transform', 'translate(' + ((order * 290) + 30) + ', 10)').attr('class', 'uniq uniq' + curves.UWI + curves.trackorder);

            }
            //  const mainGroup = d3.select('.mainGrp' +order).append('g').attr('class', 'mainGrp mainGrp' + curves.UWI + curves.trackorder).attr('transform', 'translate(' + ((order * 290) + 10) + ', 10)').append('g');
            const formgrp = mainGroup.append('g')
            const formgrpcontainer = formgrp.append('foreignObject')
              .attr('class', 'wellgroup wellgroup' + curves.UWI + curves.trackorder)
              .attr('id', 'foreignObject' + curves.UWI + curves.trackorder)
            const WellNameDiv = formgrpcontainer.append('xhtml:div')
              .attr('class', 'well-info-name')
              .html("<span class='well-title'>"+curves.wellName+"</span>");
              const Welltrack = WellNameDiv
              .append('div')
              .attr('class', 'float-right');

              const track1 = Welltrack.append('span').attr('class','one');
              const track2 = Welltrack.append('span').attr('class','two');

              track1.append('i')
              .attr('class', 'fa fa-ellipsis-h').on('click', function (d) {
               // d3.select('.addtrack').remove();
              });

              track2.append('i').attr('id','uniq' + curves.UWI +  curves.trackorder)
              .attr('class', 'fa fa-times').on('click', function (d) {
                 alert(this.id);
                 d3.select('.addtrack').remove();
                d3.select("."+this.id).remove();
                 translateGenerator();
                
              });


              track1.on('click', function (d) {
                console.log(document.querySelectorAll('.addtrack').length)
                const trackLength = document.querySelectorAll('.addtrack').length;
             
                if (trackLength == 0) {
                  const div = d3.select('body').append('div').attr('class', 'addtrack')

                    div.selectAll('ul')
                    .data(dropData)
                    .enter()
                    .append('ul')
                    .attr('id', 'mainGrp' + curves.UWI + curves.trackorder)
                    .on('click', function (d) {
                      d3.select('.addtrack').remove();
                      console.log(d3.select(this).node().id) //Add Track Api
                      alert(d3.select(this).node().innerText);
                      var dropdatatext = d3.select(this).node().innerText;
                      if(dropdatatext =="Delete")
                      {
                         alert(this.id);
                         d3.select("."+this.id).remove();                        
                         translateGenerator();
                      }
                      if(dropdatatext =="Add Track")
                      {
                      var trackId = d3.select(this).node().id;

                      var referenceGroup = d3.select('.' + trackId);

                      var element = d3.select('.' + trackId).node();
                      var trackWidth = element.getBoundingClientRect().width + 30;

                      console.log(element.getBoundingClientRect().width)
                      console.log(d3.select('.' + trackId).node().getAttribute('transform'));
                      
                      //var lotalUniq= d3.selectAll('.' + trackId +' .uniq').length;
                      var lotalUniq = document.querySelectorAll('.' + trackId + '  .uniq').length + 1;
                      referenceGroup.append('g').attr('class', 'uniq uniq' + curves.UWI + lotalUniq).attr('transform', 'translate(' + trackWidth + ',10)')

                      // .append('rect').attr('width', '250').attr('height', '250').attr('fill', 'lightgrey')
                      const formgrp = d3.select('.uniq' + curves.UWI + lotalUniq).append('g')
                      const formgrpcontainer = formgrp.append('foreignObject')
                        .attr('class', 'wellgroup wellgroup' + curves.UWI + lotalUniq)
                        .attr('id', 'foreignObject' + curves.UWI + lotalUniq)
                      const WellNameDiv = formgrpcontainer.append('xhtml:div')
                        .attr('class', 'well-info-name')
                        // .style('visibility', 'hidden')
                        .html("<span>"+curves.wellName+"</span>");
                        const Welltrack = WellNameDiv
                        .append('div')
                        .attr('class', 'float-right');
                        const track1 = Welltrack.append('span').attr('class','one');
                        const track2 = Welltrack.append('span').attr('class','two');

                        track1.append('i')
                        .attr('class', 'fa fa-ellipsis-h') .on('click',function(e){                          
                          //d3.select('.addtrack').remove();
                        });
                        track2.append('i').attr('id','uniq' + curves.UWI + lotalUniq)
                        .attr('class', 'fa fa-times')
                        .on('click',function(e){                          
                          alert(this.id);
                          d3.select('.addtrack').remove();
                          d3.select("."+this.id).remove();
                          translateGenerator();
                        });
                      }

                      const WellInfoproductDiv = d3.select('#foreignObject' + curves.UWI + lotalUniq).append('xhtml:div')
                        .attr('class', 'well-info-product')
                        .attr('id', 'well-info-product' + curves.UWI + lotalUniq); // Need to change when working for subtrack 

                      //Creating RadioLas -START
                      const LasRadioDiv = WellInfoproductDiv.append('div')
                        .attr('class', 'custom-control custom-radio custom-control-inline')

                      const LasBtn = LasRadioDiv.append('input')
                        .attr('class', 'custom-control-input')
                        .attr('type', 'radio')
                        .attr('name', 'inlineRadioOptions' + curves.UWI +lotalUniq)
                        .attr('id', 'inlineRadioLas' + curves.UWI +lotalUniq)
                        .attr('data-id', 'Las' +curves.UWI + lotalUniq)
                        .attr('value', 'LAS' + curves.UWI + lotalUniq + curves.curveName)
                        .on('change', function (d) {
                          console.log('button changed to ' + this.value);
                          if (this.value == "LAS" + curves.UWI + lotalUniq + curves.curveName) {
                            d3.select(`.uniq${curves.UWI + lotalUniq} .rasterGrp`).style('display', 'none');
                            d3.select(`.uniq${curves.UWI + lotalUniq} .loader`).style('display', 'block');

                            d3.json("http://localhost:8080/getLASData?uwid=" + curves.UWI + "&curveName=" + curves.curveName).then(function (data) {
                              console.log(curves.curveName + "AND" + curves.UWI)
                              const xScale = d3.scaleLinear().domain(d3.extent(data.curves, function (d) { return d[0] })).nice().range([0, 210]); // Xaxis Scale
                              const yScale = d3.scaleLinear().domain([d3.max(data.curves, function (d) { return d[1] }), d3.min(data.curves, function (d) { return d[1] })]).range([300, 0]); // Yaxis Scale

                              const xAxis = d3.axisTop(xScale).tickSize(-300).ticks(5); // Xaxis 
                              const yAxis = d3.axisLeft(yScale).tickSize(-210).ticks(5); // Y axis 
                              const line = d3.line()
                                .x(function (d) { return xScale(d[0]) })
                                .y(function (d) { return yScale(d[1]) })
                                .curve(d3.curveCardinal) // Cardinal graph generater
                              const grp = d3.select('.uniq' + curves.UWI + lotalUniq + ' g');
                              console.log(`.uniq${curves.UWI + lotalUniq}`);
                              const chartGroup = grp.append('g').attr('class', 'chartGrp chartGrp' + curves.UWI + lotalUniq).attr('transform', 'translate(30 ,160)');
                              // const cgrp = d3.select('chartGrp' +uwid + curveName);
                              // console.log(cgrp);
                              //const rastergrp = grp.append('g').attr('class', 'rasterGrp' + _well[0].UWI.UWI + _well[0].UWI.curveName).attr('transform', 'translate(' + ((order * 290)) + ',100)');
                              const grpXAxis = chartGroup.append('g').attr('class', 'axisred').attr('transform', 'translate(7,0)').transition()
                                .duration(3000);
                              grpXAxis.call(xAxis);
                              const grpYAxis = chartGroup.append('g').attr('class', 'axisred').attr('transform', 'translate(7,0)').transition()
                                .duration(3000);
                              grpYAxis.call(yAxis);

                              d3.select(`.uniq${curves.UWI + lotalUniq}  .loader`).style('display', 'none');
                              /// Drawing Path by sending Data points 
                              chartGroup.append("path")
                                .transition()
                                .duration(6000)
                                .attr('transform', 'translate(11,2)')
                                .attr("d", line(data.curves))
                                .attr('class', 'lasgrp')
                                .attr('fill', 'none')
                                .attr('stroke-width', 1)
                                .attr('stroke', data.curveColor)
                            })






                            if (curves.curveNames) {
                              //  document.querySelector('.lasdropdownUS01097200140000').selectedIndex = _well[0].curveNames.indexOf(_well[0].curveName)
                              d3.select(`.lasdropdown${curves.UWI + lotalUniq}`).property("selectedIndex", curves.curveNames.indexOf(curves.curveName));

                            } else {
                              d3.select(`.uniq${curves.UWI + lotalUniq} .loader`).style('display', 'none');
                            }
                            //console.log(_well[0].curveNames);
                            d3.select('.chartGrp' + curves.UWI + lotalUniq + curves.curveName).style('display', 'block');
                            d3.select('.rasterGrp' + curves.UWI + lotalUniq + curves.curveName).style('display', 'none');
                            d3.select('.lasdropdown' + curves.UWI + lotalUniq).style('display', 'block');
                            d3.selectAll('.wellgroup' + curves.UWI + lotalUniq).style('height', '130px');
                          }
                          else if (this.value == "Raster" + curves.UWI + lotalUniq + _well[0].curveName) {
                            d3.select('.chartGrp' + curves.UWI + lotalUniq + curves.curveName).style('display', 'none');
                            d3.select('.rasterGrp' + curves.UWI + lotalUniq + curves.curveName).style('display', 'block');
                            d3.select('.lasdropdown' + curves.UWI + lotalUniq).style('display', 'none');
                            d3.selectAll('.wellgroup' + curves.UWI + lotalUniq).style('height', '84px')
                          }
                        });


                      const laslabel = LasRadioDiv.append('label')
                        .attr('class', 'custom-control-label')
                        .attr('for', 'inlineRadioLas' +curves.UWI+ lotalUniq)
                        .html('LAS');


                      //Creating RadioLas -END

                      //Creating RadioRaster -START
                      const RasterRadioDiv = WellInfoproductDiv.append('div')
                        .attr('class', 'custom-control custom-radio custom-control-inline')


                      const RasterBtn = RasterRadioDiv.append('input')
                        .attr('class', 'custom-control-input')
                        .attr('type', 'radio')
                        .attr('name', 'inlineRadioOptions' +curves.UWI+ lotalUniq)
                        .attr('id', 'inlineRadioRaster' +curves.UWI+ lotalUniq)
                        .attr('data-id', 'raster' + curves.UWI+ lotalUniq)
                        .attr('value', 'Raster' + curves.UWI + lotalUniq + curves.curveName)
                        .attr('checked', 'checked')
                        .on('change', function (d) {
                          if (this.value == "Raster" + curves.UWI + lotalUniq + curves.curveName) {
                            d3.select(`.uniq${curves.UWI + lotalUniq} .chartGrp`).remove();
                            d3.select(`.uniq${curves.UWI + lotalUniq} .rasterGrp`).style('display', 'block');

                            console.log("Raster" + curves.UWI + lotalUniq + curves.curveName)
                            d3.select('.chartGrp' + curves.UWI + lotalUniq + curves.curveName).style('display', 'none');
                            d3.select('.rasterGrp' + curves.UWI + lotalUniq + curves.curveName).style('display', 'block');
                            d3.select('.lasdropdown' + curves.UWI + lotalUniq).style('display', 'none');
                            d3.selectAll('.wellgroup' + curves.UWI + lotalUniq).style('height', '84px')

                          }
                          else if (this.value == "LAS" + curves.UWI + lotalUniq + curves.curveName) {
                            d3.select('.chartGrp' + curves.UWI + lotalUniq + curves.curveName).style('display', 'block');
                            d3.select('.rasterGrp' + curves.UWI + lotalUniq + curves.curveName).style('display', 'none');
                            d3.select('.lasdropdown' + curves.UWI + lotalUniq).style('display', 'show');
                            d3.selectAll('.wellgroup' + curves.UWI + lotalUniq).style('height', '130px')


                          }
                        });
                      const Rasterlabel = RasterRadioDiv.append('label')
                        .attr('class', 'custom-control-label')
                        .attr('for', 'inlineRadioRaster' + curves.UWI +lotalUniq)
                        .html('Raster');

                      const rasterGroup = d3.select('.uniq' + curves.UWI + lotalUniq + ' g').append('g').attr('class', 'rasterGrp rasterGrp' + _well[0].UWI + _well[0].curveName).attr('transform', 'translate(0,100)');

                      var rasterImg = rasterGroup.append('foreignObject')
                        .attr('width', '250')
                        .attr('height', '380')

                      const rasterDiv = rasterImg.append('xhtml:div')
                        .attr('class', 'rastergrp imggrp')
                        .append('img')
                        .attr('src', 'http://localhost:8080/getTiffFile?tiffFileName=us50089200010000_4629856')
                        .attr('class', 'imgsize')

                      const loaderGrp = d3.select('.uniq' + curves.UWI + lotalUniq + ' g').append('g').attr('class', 'loader').attr('display', 'none').attr('transform', 'translate(0,130)');
                      loaderGrp.append('foreignObject').attr('width', '250')
                        .attr('height', '150')

                        .append('xhtml:div')
                        .attr('class', 'fa-4x')
                        .append('i')
                        .attr('class', 'fas fa fa-spinner fa-spin')
                      //Creating LasDropDown -START
                      const LasDropDown = WellInfoproductDiv.append('div')
                        .attr('class', 'form-group')
                        .append('select')
                        .attr('class', 'form-control lasdropdown lasdropdown' + curves.UWI + lotalUniq)
                        .style('display', 'none')
                      if (curves.curveNames) {
                        //.append("option")
                        LasDropDown.selectAll("option")
                          .data(curves.curveNames)
                          .enter()
                          .append("option")
                          .attr("value", function (d) { return d })
                          .text(function (d) { return d })

                      } else {
                        LasDropDown
                          .append("option")
                          .attr("value", "No Data Found")
                          .text("No Data Found")
                      }

                      //Creating RadioDropDown -END
                      LasDropDown.on('change', function (d) {
                        console.log(this.value)
                        this.curveName = this.value;
                        d3.select(`.uniq${curves.UWI + lotalUniq} .loader`).style('display', 'block');
                        d3.select(`.uniq${curves.UWI + lotalUniq} .chartGrp`).remove();
                        // drawPath(curves.UWI, this.value);
                        setTimeout(function () {
                          d3.select('.chartGrp' + curves.UWI + lotalUniq + this.value).style('display', 'block');
                        }, 5000)

                        console.log('.chartGrp' + curves.UWI + lotalUniq + this.value)

                        d3.json("http://localhost:8080/getLASData?uwid=" + curves.UWI + "&curveName=" + this.value).then(function (data) {
                          console.log(curves.curveName + "AND" + curves.UWI)
                          const xScale = d3.scaleLinear().domain(d3.extent(data.curves, function (d) { return d[0] })).nice().range([0, 210]); // Xaxis Scale
                          const yScale = d3.scaleLinear().domain([d3.max(data.curves, function (d) { return d[1] }), d3.min(data.curves, function (d) { return d[1] })]).range([300, 0]); // Yaxis Scale

                          const xAxis = d3.axisTop(xScale).tickSize(-300).ticks(5); // Xaxis 
                          const yAxis = d3.axisLeft(yScale).tickSize(-210).ticks(5); // Y axis 
                          const line = d3.line()
                            .x(function (d) { return xScale(d[0]) })
                            .y(function (d) { return yScale(d[1]) })
                            .curve(d3.curveCardinal) // Cardinal graph generater
                          const grp = d3.select('.uniq' + curves.UWI + lotalUniq + ' g');
                          console.log(`.uniq${curves.UWI + lotalUniq}`);
                          const chartGroup = grp.append('g').attr('class', 'chartGrp chartGrp' + curves.UWI + lotalUniq).attr('transform', 'translate(30 ,160)');
                          // const cgrp = d3.select('chartGrp' +uwid + curveName);
                          // console.log(cgrp);
                          //const rastergrp = grp.append('g').attr('class', 'rasterGrp' + _well[0].UWI.UWI + _well[0].UWI.curveName).attr('transform', 'translate(' + ((order * 290)) + ',100)');
                          const grpXAxis = chartGroup.append('g').attr('class', 'axisred').attr('transform', 'translate(7,0)').transition()
                            .duration(3000);
                          grpXAxis.call(xAxis);
                          const grpYAxis = chartGroup.append('g').attr('class', 'axisred').attr('transform', 'translate(7,0)').transition()
                            .duration(3000);
                          grpYAxis.call(yAxis);

                          d3.select(`.uniq${curves.UWI + lotalUniq}  .loader`).style('display', 'none');
                          /// Drawing Path by sending Data points 
                          chartGroup.append("path")
                            .transition()
                            .duration(6000)
                            .attr('transform', 'translate(11,2)')
                            .attr("d", line(data.curves))
                            .attr('class', 'lasgrp')
                            .attr('fill', 'none')
                            .attr('stroke-width', 1)
                            .attr('stroke', data.curveColor)
                        })





                      })              

                      translateGenerator();
                      // d3.select('svg').insert( referenceGroup, '#first + *')
                    })
                    .append('li')
                    .attr('id','uniq' + curves.UWI + curves.trackorder)
                    .text(function (d) { return d })
                  d3.select('.addtrack').style('display', 'block')                  
                    .style("left", (d3.event.pageX - 153) + "px")
                    .style("top", (d3.event.pageY + 7) + "px");
                }
                else {
                  d3.selectAll('.addtrack').remove();
                }
              });
            ////Creating Well Name Frame  -END

            ////Creating Radio and DropDown Frame  -START
            //Adding DIV inside this div ,3 div will be appended for radioLas ,radioRaster,LasDropDown
            const WellInfoproductDiv = d3.select('#foreignObject' + curves.UWI + curves.trackorder).append('xhtml:div')
              .attr('class', 'well-info-product')
              .attr('id', 'well-info-product' + curves.UWI + curves.trackorder); // Need to change when working for subtrack 

            //Creating RadioLas -START
            const LasRadioDiv = WellInfoproductDiv.append('div')
              .attr('class', 'custom-control custom-radio custom-control-inline')

            const LasBtn = LasRadioDiv.append('input')
              .attr('class', 'custom-control-input')
              .attr('type', 'radio')
              .attr('name', 'inlineRadioOptions' + order)
              .attr('id', 'inlineRadioLas' + order)
              .attr('data-id', 'Las' + order)
              .attr('value', 'LAS' + curves.UWI + curves.trackorder + curves.curveName)
              .on('change', function (d) {
                console.log('button changed to ' + this.value);
                if (this.value == "LAS" + curves.UWI + curves.trackorder + curves.curveName) {
                  d3.select(`.uniq${curves.UWI + curves.trackorder} .rasterGrp`).style('display', 'none');
                  d3.select(`.uniq${curves.UWI + curves.trackorder} .loader`).style('display', 'block');

                  drawPath(curves.UWI, curves.curveName);
                  if (curves.curveNames) {
                    //  document.querySelector('.lasdropdownUS01097200140000').selectedIndex = _well[0].curveNames.indexOf(_well[0].curveName)
                    d3.select(`.lasdropdown${curves.UWI + curves.trackorder}`).property("selectedIndex", curves.curveNames.indexOf(curves.curveName));

                  } else {
                    d3.select(`.uniq${curves.UWI + curves.trackorder} .loader`).style('display', 'none');
                  }
                  //console.log(_well[0].curveNames);
                  d3.select('.chartGrp' + curves.UWI + curves.trackorder + curves.curveName).style('display', 'block');
                  d3.select('.rasterGrp' + curves.UWI + curves.trackorder + curves.curveName).style('display', 'none');
                  d3.select('.lasdropdown' + curves.UWI + curves.trackorder).style('display', 'block');
                  d3.selectAll('.wellgroup' + curves.UWI + curves.trackorder).style('height', '130px');
                }
                else if (this.value == "Raster" + curves.UWI + curves.trackorder + _well[0].curveName) {
                  d3.select('.chartGrp' + curves.UWI + curves.trackorder + curves.curveName).style('display', 'none');
                  d3.select('.rasterGrp' + curves.UWI + curves.trackorder + curves.curveName).style('display', 'block');
                  d3.select('.lasdropdown' + curves.UWI + curves.trackorder).style('display', 'none');
                  d3.selectAll('.wellgroup' + curves.UWI + curves.trackorder).style('height', '84px')
                }
              });


            const laslabel = LasRadioDiv.append('label')
              .attr('class', 'custom-control-label')
              .attr('for', 'inlineRadioLas' + order)
              .html('LAS');


            //Creating RadioLas -END

            //Creating RadioRaster -START
            const RasterRadioDiv = WellInfoproductDiv.append('div')
              .attr('class', 'custom-control custom-radio custom-control-inline')


            const RasterBtn = RasterRadioDiv.append('input')
              .attr('class', 'custom-control-input')
              .attr('type', 'radio')
              .attr('name', 'inlineRadioOptions' + order)
              .attr('id', 'inlineRadioRaster' + order)
              .attr('data-id', 'raster' + order)
              .attr('value', 'Raster' + curves.UWI + curves.trackorder + curves.curveName)
              .attr('checked', 'checked')
              .on('change', function (d) {
                if (this.value == "Raster" + curves.UWI + curves.trackorder + curves.curveName) {
                  d3.select(`.uniq${curves.UWI + curves.trackorder} .chartGrp`).remove();
                  d3.select(`.uniq${curves.UWI + curves.trackorder} .rasterGrp`).style('display', 'block');

                  console.log("Raster" + curves.UWI + curves.trackorder + curves.curveName)
                  d3.select('.chartGrp' + curves.UWI + curves.trackorder + curves.curveName).style('display', 'none');
                  d3.select('.rasterGrp' + curves.UWI + curves.trackorder + curves.curveName).style('display', 'block');
                  d3.select('.lasdropdown' + curves.UWI + curves.trackorder).style('display', 'none');
                  d3.selectAll('.wellgroup' + curves.UWI + curves.trackorder).style('height', '84px')

                }
                else if (this.value == "LAS" + curves.UWI + curves.trackorder + curves.curveName) {
                  d3.select('.chartGrp' + curves.UWI + curves.trackorder + curves.curveName).style('display', 'block');
                  d3.select('.rasterGrp' + curves.UWI + curves.trackorder + curves.curveName).style('display', 'none');
                  d3.select('.lasdropdown' + curves.UWI + curves.trackorder).style('display', 'show');
                  d3.selectAll('.wellgroup' + curves.UWI + curves.trackorder).style('height', '130px')


                }
              });
            const Rasterlabel = RasterRadioDiv.append('label')
              .attr('class', 'custom-control-label')
              .attr('for', 'inlineRadioRaster' + order)
              .html('Raster');

            //Creating RadioRaster -END

            //Creating LasDropDown -START
            const LasDropDown = WellInfoproductDiv.append('div')
              .attr('class', 'form-group')
              .append('select')
              .attr('class', 'form-control lasdropdown lasdropdown' + curves.UWI + curves.trackorder)
              .style('display', 'none')
            if (curves.curveNames) {
              //.append("option")
              LasDropDown.selectAll("option")
                .data(curves.curveNames)
                .enter()
                .append("option")
                .attr("value", function (d) { return d })
                .text(function (d) { return d })

            } else {
              LasDropDown
                .append("option")
                .attr("value", "No Data Found")
                .text("No Data Found")
            }

            //Creating RadioDropDown -END
            LasDropDown.on('change', function (d) {
              console.log(this.value)
              this.curveName = this.value;
              d3.select(`.uniq${curves.UWI + curves.trackorder} .loader`).style('display', 'block');
              d3.select(`.uniq${curves.UWI + curves.trackorder} .chartGrp`).remove();
              drawPath(curves.UWI, this.value);
              setTimeout(function () {
                d3.select('.chartGrp' + curves.UWI + curves.trackorder + this.value).style('display', 'block');
              }, 5000)

              console.log('.chartGrp' + curves.UWI + curves.trackorder + this.value)
            })
            ////Creating Radio and DropDown Frame  -END
            //Creating Loader inside main Grp -START
            const loaderGrp = d3.select('.uniq' + curves.UWI + curves.trackorder + ' g').append('g').attr('class', 'loader').attr('display', 'none').attr('transform', 'translate(0,130)');
            loaderGrp.append('foreignObject').attr('width', '250')
              .attr('height', '150')

              .append('xhtml:div')
              .attr('class', 'fa-4x')
              .append('i')
              .attr('class', 'fas fa fa-spinner fa-spin')
            //Creating Loader inside main Grp -END
            //.attr('id','uniq'+curves.trackorder)
            // const rasterGroup = d3.select('.mainGrp' + curves.UWI + 1 + ' g').append('g').attr('class', 'rasterGrp rasterGrp' + _well[0].UWI.UWI + _well[0].UWI.curveName).attr('transform', 'translate(0,100)');
            const rasterGroup = d3.select('.uniq' + curves.UWI + curves.trackorder + ' g').append('g').attr('class', 'rasterGrp rasterGrp' + _well[0].UWI + _well[0].curveName).attr('transform', 'translate(0,100)');

            var rasterImg = rasterGroup.append('foreignObject')
              .attr('width', '250')
              .attr('height', '380')

            const rasterDiv = rasterImg.append('xhtml:div')
              .attr('class', 'rastergrp imggrp')
              .append('img')
              .attr('src', 'http://localhost:8080/getTiffFile?tiffFileName=us50089200010000_4629856')
              .attr('class', 'imgsize')

            //drawPath(_well[0].UWI, _well[0].curveName);
            ///Creating Chart Group  -START
            function drawPath(uwid, curveName) {
              if (curves.rasterLasFlag == 'Las') {

                d3.json("http://localhost:8080/getLASData?uwid=" + uwid + "&curveName=" + curveName).then(function (data) {
                  console.log(curveName + "AND" + uwid)
                  const xScale = d3.scaleLinear().domain(d3.extent(data.curves, function (d) { return d[0] })).nice().range([0, 210]); // Xaxis Scale
                  const yScale = d3.scaleLinear().domain([d3.max(data.curves, function (d) { return d[1] }), d3.min(data.curves, function (d) { return d[1] })]).range([300, 0]); // Yaxis Scale

                  const xAxis = d3.axisTop(xScale).tickSize(-300).ticks(5); // Xaxis 
                  const yAxis = d3.axisLeft(yScale).tickSize(-210).ticks(5); // Y axis 
                  const line = d3.line()
                    .x(function (d) { return xScale(d[0]) })
                    .y(function (d) { return yScale(d[1]) })
                    .curve(d3.curveCardinal) // Cardinal graph generater
                  const grp = d3.select('.uniq' + curves.UWI + curves.trackorder + ' g');
                  console.log(`.mainGrp${uwid + curves.trackorder}`);
                  const chartGroup = grp.append('g').attr('class', 'chartGrp chartGrp' + uwid + curves.trackorder + curveName).attr('transform', 'translate(30 ,160)');
                  // const cgrp = d3.select('chartGrp' +uwid + curveName);
                  // console.log(cgrp);
                  //const rastergrp = grp.append('g').attr('class', 'rasterGrp' + _well[0].UWI.UWI + _well[0].UWI.curveName).attr('transform', 'translate(' + ((order * 290)) + ',100)');
                  const grpXAxis = chartGroup.append('g').attr('class', 'axisred').attr('transform', 'translate(7,0)').transition()
                    .duration(3000);
                  grpXAxis.call(xAxis);
                  const grpYAxis = chartGroup.append('g').attr('class', 'axisred').attr('transform', 'translate(7,0)').transition()
                    .duration(3000);
                  grpYAxis.call(yAxis);

                  d3.select(`.uniq${curves.UWI + curves.trackorder}  .loader`).style('display', 'none');
                  /// Drawing Path by sending Data points 
                  chartGroup.append("path")
                    .transition()
                    .duration(6000)
                    .attr('transform', 'translate(11,2)')
                    .attr("d", line(data.curves))
                    .attr('class', 'lasgrp')
                    .attr('fill', 'none')
                    .attr('stroke-width', 1)
                    .attr('stroke', data.curveColor)
                })
              }
            }

            /// Function to generate transform translate and rearange the main Group
            function translateGenerator() {
              var listItem = document.querySelectorAll(".mainGrp ");

              var newNums = [];

              for (var i = 0; i < listItem.length; i++) {
                newNums.push(parseInt((listItem[i].getBoundingClientRect().width), 10));
              }
              console.log(newNums);
              for (var i = 0; i < listItem.length; i++) {
                if (i !== 0) {
                  console.log(d3.select(`.mainGrp:nth-child(${i + 1})`))
                  d3.select(`.mainGrp:nth-child(${i + 1})`).attr('transform', `translate(${newNums[i - 1] + 40},10)`)
                }
                else{
                  d3.select(`.mainGrp:nth-child(${i + 1})`).attr('transform', `translate(40,10)`)
                }
              }

              console.log(newNums)

            }

            ///Creating Chart Group -END




            //  drawD3Curve(_well[0]);
            //   });
            order = order + 1;
          });
        });
      })
      .catch(console.error());

    function getDropDownData(_uwid, _curveName): Promise<any> {
      var list = d3.json("http://localhost:8080/getLASData?uwid=" + _uwid + "&curveName=" + _curveName).then(function (data) {
        console.log(data)
        return Object.keys(data.curveInformation);

      }).catch(function (error) {
        console.log(error)
      })
      return list;
    }


  }

}
