/*Global Variables Section*/
//Declare your Global Variables inside this block
TotalList = [];
TotalList1 = [];
TotalImgist = [];
FilteredList = [];

function drag(ev) {};

function drop(ev) {};

function allowDrop(ev) {};

/*End of Global Variables*/

// A $(document).ready() block.
$(document).ready(function() {
    callThis();


});

//Get List of Products from the database
function getProducts() {
    var urls;
    for (var i = 0; i < TotalList.length; i++) {
        if(! TotalList[i].productImg )

            urls = "../images/product.png";
    else
         urls = "../images/Product/" + TotalList[i].productImg.fileName;
        TotalList1.push(TotalList[i].category);


        if(TotalList[i].description.length > 105)
        var shortText = jQuery.trim(TotalList[i].description).substring(0,105).split(" ").slice(0, -1).join(" ") + ".........."
        else
        shortText=TotalList[i].description;

        $("#prodlist").append("<div id=\"products\" class=\"col-lg-12 col-md-12 col-sm-12 col-xs-12\">\
        <div class=\"prodImage col-lg-4 col-md-4 col-sm-4 col-xs-4\">\
        <input type=\"file\" class=\"my_file\" id=\"my_file\" "+TotalList[i]._id+"/>\
        <img class=\"imgupload\" id=\"img\" src=" + urls + " />\
        <div class=\"pull-right\" style=\"cursor: pointer;\"><a id=" + TotalList[i]._id + " href=\"javascript:void(0)\" class=\"upload_click\"><i class=\"fa fa-upload\"></i>Upload</a></div></div> \
        <div class=\"about col-lg-offset-1 col-md-offset-1 col-lg-7 col-md-7 col-sm-7 col-xs-7\">\
                                <p>" + TotalList[i].name + "</p>\
                                <p class=\"tooltip\">" + shortText + "<span class=\"tooltiptext\">"+TotalList[i].description+"</span></p> \
                                <p><span>" + TotalList[i].category + "</span></p>   \
                                <p><span>RS: </span>" + TotalList[i].price + "</p></div>\
                                <div class=\"buttonBar col-lg-12 col-md-12 col-sm-12 col-xs-12\">\
                                <div class=\"pull-right col-lg-3 col-md-3 col-sm-3 col-xs-3\">\
                                <button id=" + TotalList[i]._id + " onclick=\"remove(this)\" data-toggle=\"modal\" data-target=\"#myModal\" class=\"btn btn-danger col-lg-6 col-md-6 col-sm-6 col-xs-6\"><i class=\"fa fa-trash-o\"></i>Remove</button>   \
                                <button id=" + TotalList[i]._id + " onclick=\"editProduct(" + i + ")\" class=\"btn btn-success col-lg-5 col-md-5 col-sm-5 col-xs-5\"><i class=\"fa fa-pencil-square-o\"></i>Edit</button>   \
                                </div></div></div>");
    }
    TotalList1 = $.grep(TotalList1, function(v, k) {
        return $.inArray(v, TotalList1) === k;
    });


    for (var i = 0; i < TotalList1.length; i++) {
        $("#cats").append("<div id=\"p" + i + "\" draggable=\"true\" ondragstart=\"drag(event)\" class=\"bin\"><button  class=\"btn btn-success\">" + TotalList1[i] + "</button></div>");
    }

};


$(document).on('change', '.my_file', function(e) {
    $(this).next().attr('src', URL.createObjectURL(e.target.files[0]));
});


/***
Write your code for fetching the list of product from the database*/
function callThis() {
    $.ajax({

        type: 'GET',
        url: 'http://localhost:3000/products',
        dataType: 'json',
        success: function(data) {
            TotalList = data.data;
            getProducts();
        }
    })

}


 
/*
 
 Write a generic click even capture code block 
 to capture the click events of all the buttons in the HTML page

 If the button is add
 -----------------------*/
$('#submit').click(function() {
    $('#filterspace').empty();

    $('#success').hide();
    $('#error').hide();

    if (!($('#name').val()) || !($('#desc').val()) || !($('#price').val()) || !($('#category').val())) {
        $('#error').show();
    } else {

        createProduct();
        $('#success').show();
        $("#prodlist").empty();
        $("#cats").empty();
        TotalList1 = [];

        setTimeout(function() {
            $('#name').val('');
            $('#desc').val('');
            $('#price').val('    ');
            $('#category').val('');
            $('#success').hide();
        }, 1000);
        callThis();
    }
});
/*
Using jQuery Validate the form
All fields are mandatory.
Call the API
   http://localhost:3000/product
   with method=POST
   For this call data should be in following structure
   {
        name:'',
        category:'',
        description:'',
        price:''
   }

Show the success/failure messages in a message div with the corresponding color green/red
Reset the form and set the mode to Add

 
If the button is edit
---------------------
Change the Form to Edit Mode
Populate the details of the product in the form*/

var editId;

function editProduct(i) {
    editId = TotalList[i]._id;

    $("#name").val(TotalList[i].name);
    $("#desc").val(TotalList[i].description);
    $("#price").val(TotalList[i].price);
    $("#category").val(TotalList[i].category);
    $("#submit").hide();
    $("#update").show();
    var  body  =  $("html, body");
    body.stop().animate({
        scrollTop: 300
    },  500,  'swing',  function() { })
}

/*If the button is Update
Update Product*/

$('#update').click(function() {
    $("#success").show();
    $("#error2").text('Product Saved Successfully');

    $("#searchText").val('');
    $('#error').hide();
    if (!($('#name').val()) || !($('#desc').val()) || !($('#price').val()) || !($('#category').val())) {
        $('#error').show();
    } else {
        $(".removeMsg").show();
        $.ajax({
            type: 'PUT',
            url: 'http://localhost:3000/product/' + editId,
            dataType: 'json',
            data: {
                name: $('#name').val(),
                category: $('#category').val(),
                description: $('#desc').val(),
                price: $('#price').val()
            },
            success: function(data) {
                $("#prodlist").empty();
                $("#cats").empty();
                setTimeout(function() {
                    $('#name').val('');
                    $('#desc').val('');
                    $('#price').val('    ');
                    $('#category').val('');
                    $("#submit").show();
                    $(".removeMsg").hide();
                    $("#update").hide();
                    $("#success").hide();
                    $("#error2").text('Submitted Successfully');
                }, 1000);
                callThis();
            }
        });
        //write your code here to update the product and call when update button clicked    

    }
});


/*if the button is Remove
-----------------------*/
//write your code here to remove the product and call when remove button clicked
var remId;

function remove(id) {
    remId = id.id;
}

function removeProduct() {
    $.ajax({
        type: 'DELETE',
        url: 'http://localhost:3000/product/' + remId,
        dataType: 'json',
        success: function(data) {
            $('.removeMsg').show();
            setTimeout(function() {
                $('.removeMsg').hide();
            }, 1000);
            $("#prodlist").empty();
            $("#cats").empty();
            TotalList1 = [];
            callThis();
        }
    });
};




//write your code here to create  the product and call when add button clicked
function createProduct() {
    $.ajax({
        type: 'POST',
        url: 'http://localhost:3000/product',
        dataType: 'json',
        data: {
            name: $('#name').val(),
            category: $('#category').val(),
            description: $('#desc').val(),
            price: $('#price').val()
        },
        success: function(data) {
            data.url = "..public/images/product.png";
            TotalList.push(data);
        }

    });

}


/* 
    //Code Block for Drag and Drop Filter

    //Write your code here for making the Category List
    Using jQuery
    From the products list, create a list of unique categories
    Display each category as an individual button, dynamically creating the required HTML Code
*/


function allowDrop(ev) {
    ev.preventDefault();
}

function drag(ev) {
    ev.dataTransfer.setData("text", ev.target.id);
}

function drop(ev) {
    ev.preventDefault();
    var data = ev.dataTransfer.getData("text");
    ev.target.appendChild(document.getElementById(data));

    FilteredList.push($("#" + data).text());
    catFilterr();

    $("#" + data).append("<i class=\"fa fa-times-circle-o\"></i>");
    $("#" + data).on("click", "i.fa-times-circle-o", function() {

        for (var i = FilteredList.length - 1; i >= 0; i--) {
            if (FilteredList[i] === $("#" + data).text()) {
                console.log(FilteredList);
                FilteredList.splice(i, 1);
                console.log(FilteredList);

            }
        }

        catFilterr();
        $("#cats").append($(this).closest("div"));
        if (FilteredList.length == 0) {
            $("#prodlist").empty();
            $("#cats").empty();
            callThis();
        }
        $(this).closest("i").remove();

    })
}

//Write your code here for filtering the products list on Drop 
function catFilterr() {
    $("#prodlist").empty();
    $.each(TotalList, function(key, value) {
        var urls = "http://localhost:3000/product/" + TotalList[key]._id + "/image";

        for (var i = 0; i < FilteredList.length; i++) {
            if (FilteredList[i] == value.category) {
        var shortDesc = jQuery.trim(value.description).substring(0,103).split(" ").slice(0, -1).join(" ") + ".........." ;

                $("#prodlist").append("<div id=\"products\" class=\"col-lg-12 col-md-12 col-sm-12 col-xs-12\">\
        <div class=\"prodImage col-lg-4 col-md-4 col-sm-4 col-xs-4\">\
        <img src=" + urls + "   alt=\"image" + key + "\"/>\
        <div class=\"pull-right\"><a href=\"#\"><i class=\"fa fa-upload\"></i>Upload</a></div>\
        </div> \
        <div class=\"about col-lg-offset-1 col-md-offset-1 col-lg-7 col-md-7 col-sm-7 col-xs-7\">\
                                <p>" + value.name + "</p>\
                                <p class=\"tooltip\">" + shortDesc + "<span class=\"tooltiptext\">"+value.description+"</span></p> \
                                <p><span>" + value.category + "<span></p>   \
                                <p><span>RS: </span>" + value.price + "</p></div>\
                                <div class=\"buttonBar col-lg-12 col-md-12 col-sm-12 col-xs-12\">\
                                <div class=\"pull-right col-lg-3 col-md-3 col-sm-3 col-xs-3\">\
                                <button id=" + value._id + " onclick=\"remove(this)\" data-toggle=\"modal\" data-target=\"#myModal\" class=\"btn btn-danger col-lg-6 col-md-6 col-sm-6 col-xs-6\"><i class=\"fa fa-trash-o\"></i>Remove</button>   \
                                <button id=" + value._id + " onclick=\"editProduct(" + key + ")\" class=\"btn btn-success col-lg-5 col-md-5 col-sm-5 col-xs-5\"><i class=\"fa fa-pencil-square-o\"></i>Edit</button>   \
                                </div></div></div>");
            }
        }
    });
};




//Code block for Free Text Search
$(document).ready(function() {
    $("#searchText").keyup(function() {
        var search = $("#searchText").val();
        var regEx = new RegExp(search, 'i');
        $("#prodlist").empty();
        $.each(TotalList, function(key, value) {
            var urls = "http://localhost:3000/product/" + TotalList[key]._id + "/image";
            

            if (value.name.search(regEx) != -1 || value.category.search(regEx) != -1 || value.description.search(regEx) != -1 || value.price.toString().search(regEx) != -1) {
        var shortDesc = jQuery.trim(value.description).substring(0,103).split(" ").slice(0, -1).join(" ") + ".........." ;
                $("#prodlist").append("<div id=\"products\" class=\"col-lg-12 col-md-12 col-sm-12 col-xs-12\">\
        <div class=\"prodImage col-lg-4 col-md-4 col-sm-4 col-xs-4\">\
        <img src=" + urls + " alt=\"image" + key + "\"/>\
        <div class=\"pull-right\"><a href=\"#\"><i class=\"fa fa-upload\"></i>Upload</a></div>\
        </div> \
        <div class=\"about col-lg-offset-1 col-md-offset-1 col-lg-7 col-md-7 col-sm-7 col-xs-7\">\
                                <p>" + value.name + "</p>\
                                <p class=\"tooltip\">" + shortDesc + "<span class=\"tooltiptext\">"+value.description+"</span></p> \
                                <p><span>" + value.category + "<span></p>   \
                                <p><span>RS: </span>" + value.price + "</p></div>\
                                <div class=\"buttonBar col-lg-12 col-md-12 col-sm-12 col-xs-12\">\
                                <div class=\"pull-right col-lg-3 col-md-3 col-sm-3 col-xs-3\">\
                                <button id=" + value._id + " onclick=\"remove(this)\" data-toggle=\"modal\" data-target=\"#myModal\" class=\"btn btn-danger col-lg-6 col-md-6 col-sm-6 col-xs-6\"><i class=\"fa fa-trash-o\"></i>Remove</button>   \
                                <button id=" + value._id + " onclick=\"editProduct(" + key + ")\" class=\"btn btn-success col-lg-5 col-md-5 col-sm-5 col-xs-5\"><i class=\"fa fa-pencil-square-o\"></i>Edit</button>   \
                                </div></div></div>");
            }
        });

    });

});



//Code block for Image Upload
$(document).on("click", ".upload_click", function(e) {
    var file = $(this).parent().parent().find("input.my_file")[0].files[0];
    var formData = new FormData();
    formData.append('file', file, "productImage");
    console.log(file);


    $.ajax({
        type: 'PUT',
        url: 'http://localhost:3000/product/' + $(this).attr('id') + '/ProductImg',
        dataType: 'json',
        data: formData,
        contentType:  false,
        processData:  false,
        success: function(data) {
            $(".removeMsg").text("Image Uploaded Succesfully");
        $(".removeMsg").css("background","#26B99A");

        $(".removeMsg").show();
            setTimeout(function() {
                $(".removeMsg").text("Succesfully Removed");
        $(".removeMsg").css("background","#26B99A");

                $('.removeMsg').hide();
            }, 3000);
        }
    });
    if($("input.my_file")[0].files.length === 0){
        $(".removeMsg").css("background","red");
     $(".removeMsg").text("Click on an image to select a new file");
        $(".removeMsg").show();   
        setTimeout(function() {
                $('.removeMsg').hide();
        $(".removeMsg").css("background","#26B99A");
                
            }, 3000);
             
}
});
/*
    //Write your Code here for the Image Upload Feature
    Make the product image clickable in the getProducts() method.
    When the user clicks on the product image
    Open the file selector window
    Display the selected image as a preview in the product tile
    
    //Image Upload
    When the user clicks Upload
    Using AJAX
    Update the product image using the following api call
        Call the api
            http://localhost:3000/product/id/ProductImg
            method=PUT
            the data for this call should be as FormData
            eg:
            var formData = new FormData();
            formData.append('file', file, file.name);
    
    Refresh the products list to show the new image
 */