import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { HttpClient } from '@angular/common/http';

@Injectable({
  providedIn: 'root'
})
export class DataService {

  constructor(private _http: HttpClient) { }

  getHttpData(): Observable<any> {
    //  const headers = new HttpHeaders({ 'Content-Type': 'application/json', 'Access-Control-Allow-Origin': "*" });
    const lasUrl = "http://localhost:8080/getCrossSectionDetails?crossSectionName=crossSection1";
    const rasterUrl = "http://localhost:8080/getRasterData?uwiId=12"
    return this._http.get<any>(lasUrl);
  }

   getCrossSectionData(uwid,curveName): Observable<any> {
    //  const headers = new HttpHeaders({ 'Content-Type': 'application/json', 'Access-Control-Allow-Origin': "*" });
    const lasUrl = `http://localhost:8080/getLASData?uwid=${uwid}&curveName=${curveName}`;
    const rasterUrl = "http://localhost:8080/getRasterData?uwiId=12"
    return this._http.get<any>(lasUrl)
  }
}
