
// // //   private createDynamicWells(curveData) {

// // //     var svgContainer = d3.select('svg');
// // //     svgContainer.attr('width', screen.availWidth);
// // //     svgContainer.attr('height', screen.availHeight);
// // //     var wellnames = Object.keys(curveData.curveInformation);

// // //     var data = [1, 2, 3]
// // //     //create group inside svgContainer
// // //     var grp = svgContainer.selectAll('g')
// // //       .data(wellnames)
// // //       .enter()
// // //       .append('g')
// // //     var rect = grp.append('rect')
// // //       .attr('width', screen.availWidth / 5)
// // //       .attr('height', screen.availHeight)
// // //       .attr('stroke-width', 5)
// // //       .attr('stroke', 'black')
// // //       .attr('fill', 'orange')
// // //       .attr('x', function (data, i) { return 300 * i });


// // //     var text = grp.append("text")
// // //       .attr("x", function (d, i) { return 320 * i })
// // //       .attr("y", screen.availWidth / wellnames.length)
// // //       .attr("dy", ".35em")
// // //       .text(function (d) { return d; });

// // //     var fobject = grp.append('foreignObject')
// // //       .attr('x', function (d, i) { return 320 * i })
// // //       .attr('y', 250)
// // //       .attr('height', 100)
// // //       .attr('width', 200)
// // //       .append('xhtml:div')
// // //       .append("select")

// // //     fobject.selectAll("option")

// // //       .data(Object.keys(curveData.wellInformation))

// // //       // .data(function (curveData) {
// // //       //   let options = Object.keys(curveData.wellInformation)
// // //       //   return options
// // //       // })
// // //       .enter()
// // //       .append("option")
// // //       .attr("value", function (d) { return d })
// // //       .text(function (d) { return d })


// // //   }


// // //   private insideEveryGroup(wellnames) {
// // //     var svgContainer = d3.select('svg');
// // //     svgContainer.attr('width', screen.availWidth);
// // //     svgContainer.attr('height', screen.availHeight);

// // //     svgContainer.selectAll('g')
// // //       .data(wellnames)
// // //       .enter()
// // //       .append('g')
// // //       .append("rect")
// // //       .attr('width', screen.availWidth / 5)
// // //       .attr('height', screen.availHeight)
// // //       .attr('stroke-width', 5)
// // //       .attr('stroke', 'black')
// // //       .attr('fill', 'none')
// // //       .attr('x', function (data, i) { return 300 * i })

// // //       .append('foreignObject')
// // //       .attr('x', function (d, i) { return 320 * i })
// // //       .attr('y', screen.availWidth / wellnames.length)
// // //       .attr('width', 200)
// // //       .append('xhtml:div')
// // //       .attr('height', 190)
// // //       .attr('width', 20)
// // //       // .append('p').html(function (d) { return d.DisplayText; })
// // //       // .append('text')
// // //       // .attr("x", function (d, i) { return 320 * i })
// // //       // .attr("y", screen.availWidth / wellnames.length)
// // //       // .attr("dy", ".35em")
// // //       .text(function (d) { return d.DisplayText; });



// // //   }
// // //   private newWells(wellnames) {
// // //     var svgContainer = d3.select('svg');
// // //     svgContainer.attr('width', screen.availWidth);
// // //     svgContainer.attr('height', screen.availHeight);
// // //     var data = [1, 2, 3]
// // //     //create group inside svgContainer
// // //     var appendrect = svgContainer.append("g")
// // //       .selectAll("rect")
// // //       .data(wellnames)
// // //       .enter()
// // //       .append("rect")
// // //       .attr('width', screen.availWidth / 5)
// // //       .attr('height', screen.availHeight)
// // //       .attr('stroke-width', 5)
// // //       .attr('stroke', 'black')
// // //       .attr('fill', 'orange')
// // //       .attr('x', function (data, i) { return 300 * i })
// // //       .append('foreignObject')
// // //       .attr('x', function (d, i) { return 320 * i })
// // //       .attr('y', screen.availWidth / wellnames.length)
// // //       .attr('height', 190)
// // //       .attr('width', 20)

// // //       .append('text')
// // //       .attr("x", function (d, i) { return 320 * i })
// // //       .attr("y", screen.availWidth / wellnames.length)
// // //       .attr("dy", ".35em")
// // //       .text(function (d) { return d.DisplayText; });




// // //   }

// // //   private createGroup(data) {
// // //     // var svgContainer = d3.select('svg');
// // //     // svgContainer.attr('width', screen.availWidth);
// // //     // svgContainer.attr('height', screen.availHeight);
// // //     // //create group inside svgContainer
// // //     // svgContainer.append("g").selectAll("rect")
// // //     //   .data(data)
// // //     //   .enter()
// // //     //   .append("rect")
// // //     //   .attr('width', screen.availWidth / 5)
// // //     //   .attr('height', screen.availHeight)
// // //     //   .attr('stroke-width', 5)
// // //     //   .attr('stroke', 'black')
// // //     //   .attr('fill', 'orange')
// // //     //   .attr('x', function (d, i) {
// // //     //     return (d * i * 150)
// // //     //   })




// // //   }

// // //   private appendDiv(data) {
// // //     // var rectContainer = d3.select('svg')
// // //     // rectContainer.append('g')
// // //     //   .data(data)
// // //     //   .enter()
// // //     //   .append('circle')
// // //     //   .attr('cx', 100)
// // //     //   .attr('cy', 100)
// // //     //   .style('fill', 'green')
// // //     //   .attr('r', 50);
// // //     //.appendHTML("<span>This was added in HTML</span>")
// // //     // rectContainer.append('circle')
// // //     //   .attr('fill', 'green')
// // //     //   .attr('cx', 100)
// // //     //   .attr('cy', 100)
// // //     //   .attr('r', 20)
// // //     // var fo = rectContainer.append('foreignObject')
// // //     // var div = fo.append('xhtml:div')
// // //     //   .append('div')
// // //     //   .attr({
// // //     //     'class': 'tooltip'
// // //     //   });
// // //     // div.append('p')
// // //     //   .attr('class', 'lead')
// // //     //   .html('Holmes was certainly not a difficult man to live with.');
// // //   }
// // //   private createWells(wellnames) {
// // //     console.log(wellnames)

// // //     var svgContainer = d3.select('svg');
// // //     svgContainer.attr('width', screen.availWidth);
// // //     svgContainer.attr('height', screen.availHeight);

// // //     var data = [1, 2, 3]
// // //     //create group inside svgContainer
// // //     svgContainer.append("g")
// // //       .selectAll("rect")
// // //       .data(wellnames)
// // //       .enter()
// // //       .append("rect")
// // //       .attr('width', screen.availWidth / 5)
// // //       .attr('height', screen.availHeight)
// // //       .attr('stroke-width', 5)
// // //       .attr('stroke', 'black')
// // //       .attr('fill', 'orange')
// // //       .attr('x', function (data, i) { return 300 * i });

// // //     svgContainer.append("g")
// // //       .selectAll("rect")
// // //       .data(wellnames)
// // //       .enter()
// // //       .append("text")
// // //       .attr("x", function (d, i) { return 320 * i })
// // //       .attr("y", screen.availWidth / wellnames.length)
// // //       .attr("dy", ".35em")
// // //       .text(function (d) { return d.DisplayText; });


// // //   }

// //   // draw top on group 
// //   private drawTop(curveData) {

// //     var svgContainer = d3.select('svg');
// //     svgContainer.attr('width', screen.availWidth);
// //     svgContainer.attr('height', screen.availHeight);
// //     var wellnames = Object.keys(curveData.curveInformation);

// //     var data = [1, 2, 3]
// //     //create group inside svgContainer
// //     var grp = svgContainer.selectAll('g')
// //       .data(wellnames)
// //       .enter()
// //       .append('g')
// //     var rect = grp.append('rect')
// //       .attr('width', screen.availWidth / 5)
// //       .attr('height', screen.availHeight)
// //       .attr('stroke-width', 5)
// //       .attr('stroke', 'black')
// //       .attr('fill', 'orange')
// //       .attr('x', function (data, i) { return 300 * i });


// //     var text = grp.append("text")
// //       .attr("x", function (d, i) { return 320 * i })
// //       .attr("y", screen.availWidth / wellnames.length)
// //       .attr("dy", ".35em")
// //       .text(function (d) { return d; });

// //     var fobject = grp.append('foreignObject')
// //       .attr('x', function (d, i) { return 320 * i })
// //       .attr('y', 250)
// //       .attr('height', 100)
// //       .attr('width', 200)
// //       .append('xhtml:div')
// //       .append("select")

// //     fobject.selectAll("option")

// //       .data(Object.keys(curveData.wellInformation))

// //       // .data(function (curveData) {
// //       //   let options = Object.keys(curveData.wellInformation)
// //       //   return options
// //       // })
// //       .enter()
// //       .append("option")
// //       .attr("value", function (d) { return d })
// //       .text(function (d) { return d })
// //   }


// private drawChart(data) {

//     console.log(data.crossSectionDetails[0][0].UWI)

//     console.log(data.crossSection.totalWellCount)
//     const points: any[] = []

//     const width = 600, height = 400;
//     d3.select(".cst-card-body-container").style('overflow', 'auto');
//     const svg = d3.select(".cst-card-body-container").append("svg")
//       .attr("width", '100%').attr("height", '500');
//     const xScale = d3.scaleLinear().domain([0, d3.max(points, function (d) { return d[0] })]).range([0, 210]); // Xaxis Scale
//     const yScale = d3.scaleLinear().domain([d3.max(points, function (d) { return d[1] }), 2000]).range([300, 0]); // Yaxis Scale

//     const xAxis = d3.axisTop(xScale); // Xaxis 
//     const yAxis = d3.axisLeft(yScale); // Y axis 
//     const line = d3.line()
//       .x(function (d) { return xScale(d[0]) })
//       .y(function (d) { return yScale(d[1]) })
//       .curve(d3.curveCardinal) // Cardinal graph generater
//     for (var t = 0; t < data.crossSection.totalWellCount; t++) {

//       const grp = svg.append('g').attr('transform', 'translate(' + ((t * 290)) + ', 20)');
//       const formgrp = grp.append('g')
//       const formgrpcontainer = formgrp.append('foreignObject')
//         .attr('width', '250')
//         .attr('height', '150');
//       const formgrptitle = formgrpcontainer.append('xhtml:div')
//         .attr('class', 'well-info-name')
//         .html('Well Name ' + (t + 1))
//         .append('div')
//         .attr('class', 'float-right')
//         .append('i')
//         .attr('class', 'fa fa-times');
//       const formgrpproduct = formgrpcontainer.append('xhtml:div')
//         .attr('class', 'well-info-product');

//       const productgrp = formgrpproduct.append('div')
//         .attr('class', 'form-check form-check-inline');
//       const lasgrp = productgrp.append('input')
//         .attr('class', 'form-check-input')
//         .attr('type', 'radio')
//         .attr('name', 'inlineRadioOptions' + t)
//         .attr('id', 'inlineRadio' + t)
//         .attr('checked', 'checked')
//         .attr('data-id', t)
//         .attr('value', 'LAS')
//         .on('change', function (d) {
//           console.log('button changed to ' + this.value);
//           if (this.value == "LAS") {
//             document.querySelector('.lasgrp' + this.getAttribute('data-id')).style.display = 'block';
//             document.querySelector('.rastergrp' + this.getAttribute('data-id')).style.display = 'none';

//           }
//           else {
//             document.querySelector('.lasgrp' + this.getAttribute('data-id')).style.display = 'none';
//             document.querySelector('.rastergrp' + this.getAttribute('data-id')).style.display = 'block';

//           }
//         });

//       const lasgrplabel = productgrp.append('label')
//         .attr('class', 'form-check-label')
//         .attr('for', 'inlineRadio' + t)
//         .html('LAS');



//       const productgrp1 = formgrpproduct.append('div')
//         .attr('class', 'form-check form-check-inline');
//       const rastergrp = productgrp1.append('input')
//         .attr('class', 'form-check-input')
//         .attr('type', 'radio')
//         .attr('name', 'inlineRadioOptions' + t)
//         .attr('id', 'inlineRadio' + t)
//         .attr('data-id', t)
//         .attr('value', 'Raster')
//         .on('change', function (d) {
//           if (this.value == "Raster") {
//             document.querySelector('.lasgrp' + this.getAttribute('data-id')).style.display = 'none';
//             document.querySelector('.rastergrp' + this.getAttribute('data-id')).style.display = 'block';

//           }
//           else {
//             document.querySelector('.lasgrp' + this.getAttribute('data-id')).style.display = 'block';
//             document.querySelector('.rastergrp' + this.getAttribute('data-id')).style.display = 'none';

//           }
//         });
//       //data.crossSectionDetails[0][0].UWI,data.crossSectionDetails[0][0].curveName

//       this._http.getCrossSectionData("US01013199980000", "SPR")
//         .subscribe(
//         data => {
//         this.crsdata = data
//         }
//         )

//       // function returnData(data) {
//       //   console.log(data)
//       //   this.crsdata = data

//       // }
//       console.log(this.crsdata);
//       const rastergrplabel = productgrp1.append('label')
//         .attr('class', 'form-check-label')
//         .attr('for', 'inlineRadio' + t)
//         .html('Raster');

//       const projectlist = formgrpproduct.append('div')
//         .attr('class', 'form-group')
//         .append('select')
//         .attr('class', 'form-control')
//       projectlist.selectAll("option")
//         .data(data)
//         .enter()
//         .append("option")
//         .attr("value", function (d) { return d })
//         .text(function (d) { return d })


//       const shapegrp = grp.append('g').attr('transform', 'translate(30,160)')
//       const grpXAxis = shapegrp.append('g').attr('transform', 'translate(7,0)');
//       grpXAxis.call(xAxis);
//       const grpYAxis = shapegrp.append('g').attr('transform', 'translate(7,0)');
//       grpYAxis.call(yAxis);
//       shapegrp.append("path").attr('transform', 'translate(11,2)')
//         .attr("d", line(points))
//         .attr('class', 'lasgrp' + t)
//         .attr('fill', 'none')
//         .attr('stroke-width', 1)
//         .attr('stroke', 'blue')
//       // .on('click',function(d){
//       //     console.log('This is viajy');
//       // });
//       shapegrp.append('rect')
//         .attr('width', '220')
//         .attr('class', 'rastergrp' + t)
//         .attr('height', '300')
//         .attr('fill', 'blue')
//         .style('display', 'none');
//       shapegrp.on('click', function (e) {
//       })



//     }
//   }