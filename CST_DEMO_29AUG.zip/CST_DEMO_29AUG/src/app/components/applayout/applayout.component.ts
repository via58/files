import { Component, OnInit } from '@angular/core';
import * as d3 from 'd3';
import { DataService } from 'src/app/data-service.service';
// import {dataPoints} from 'src/app/components/applayout/chumma';
@Component({
  selector: 'app-applayout',
  templateUrl: './applayout.component.html',
  styleUrls: ['./applayout.component.scss']
})

export class ApplayoutComponent implements OnInit {

  constructor(private _http: DataService) { }
  processedData: any = [];
  curveData: any = [];
  points: any = [];
  uwid: any = "US01003201370000";
  curveName: string = "GRR";
  color: any = ['#3496f7', '#ff6600', '#85ba59', '#ffed63', '#debd9e']

  ngOnInit() {

    this._http.getHttpData()
      .subscribe(data => {
        this.processedData = data;
        console.log(data);
        // console.log(Object.keys(data.curveInformation).length);
        this.drawChart(this.processedData);

      })

  }

  private async drawChart(data) {


    const points: any[] = []

    const width = 600, height = 400;
    d3.select(".cst-card-body-container").style('overflow', 'auto');
    const svg = d3.select(".cst-card-body-container").append("svg")
      .attr("width", '100%').attr("height", '500');

    await this.productType(data);
    await this.drawCurve();


    //   await this.drawAxisandPath(data);
  }

  private async productType(data) {

    const points: any[] = [];
    //data.crossSection.totalWellCount
    for (var t = 0; t < 1; t++) {


      const grp = d3.select('svg').append('g').attr('class', 'mainGrp').attr('transform', 'translate(' + ((t * 290)) + ', 0)');
      const formgrp = grp.append('g')
      const formgrpcontainer = formgrp.append('foreignObject')
        .attr('width', '250')
        .attr('height', '150');
      const formgrptitle = formgrpcontainer.append('xhtml:div')
        .attr('class', 'well-info-name')
        .html(data.crossSectionDetails[0][0].wellName)
        .append('div')
        .attr('class', 'float-right')
        .append('i')
        .attr('class', 'fa fa-ellipsis-h');
      const formgrpproduct = formgrpcontainer.append('xhtml:div')
        .attr('class', 'well-info-product');

      const productgrp = formgrpproduct.append('div')
        .attr('class', 'custom-control custom-radio custom-control-inline');
      const lasgrp = productgrp.append('input')
        .attr('class', 'custom-control-input')
        .attr('type', 'radio')
        .attr('name', 'inlineRadioOptions' + t)
        .attr('id', 'inlineRadio1')

        .attr('data-id', t)
        .attr('value', 'LAS')
        .on('change', function (d) {
          console.log('button changed to ' + this.value);
          if (this.value == "LAS") {
            
            
            d3.select('.chartGrp').style('display', 'block');
            d3.select('.rasterGrp').style('display', 'none');
            d3.select('.lasdropdown').style('display', 'block');


          }
          else {
            d3.select('.chartGrp').style('display', 'none');
            d3.select('.rasterGrp').style('display', 'block');
            d3.select('.lasdropdown').style('display', 'none');


          }
        });

      const lasgrplabel = productgrp.append('label')
        .attr('class', 'custom-control-label')
        .attr('for', 'inlineRadio1')
        .html('LAS');



      const productgrp1 = formgrpproduct.append('div')
        .attr('class', 'custom-control custom-radio custom-control-inline');
      const rastergrp = productgrp1.append('input')
        .attr('class', 'custom-control-input')
        .attr('type', 'radio')
        .attr('name', 'inlineRadioOptions' + t)
        .attr('id', 'inlineRadio2')
        .attr('checked', 'checked')
        .attr('data-id', t)
        .attr('value', 'Raster')
        .on('change', function (d) {
          if (this.value == "Raster") {
            d3.select('.chartGrp').style('display', 'none');
            d3.select('.rasterGrp').style('display', 'block');
            d3.select('.lasdropdown').style('display', 'none');

          }
          else {
            d3.select('.chartGrp').style('display', 'block');
            d3.select('.rasterGrp').style('display', 'none');
            d3.select('.lasdropdown').style('display', 'show');


          }
        });
      //data.crossSectionDetails[0][0].UWI,data.crossSectionDetails[0][0].curveName

      //       this.drawCurve();

      this.curveData = JSON.parse(localStorage.getItem('curveData'))
      this.points = this.curveData.curves;
      const rastergrplabel = productgrp1.append('label')
        .attr('class', 'custom-control-label')
        .attr('for', 'inlineRadio2')
        .html('Raster');

      const projectlist = formgrpproduct.append('div')
        .attr('class', 'form-group')
        .append('select')
        .attr('class', 'form-control lasdropdown')
        .style('display', 'none')
      projectlist.selectAll("option")
        .data(Object.keys(this.curveData.curveInformation))
        .enter()
        .append("option")
        .attr("value", function (d) { if (d !== "DEPT") { return d } })
        .text(function (d) { if (d !== "DEPT") { return d } })
      projectlist.on('change', function (d) {
        console.log(this.value)
        this.curveName = this.value;

        d3.select('.chartGrp').remove();

        // this._http.getCrossSectionData("US01003201370000", this.value)
        //   .subscribe(
        //   data => {
        //     console.log(data)

        //     //console.log(this.points)
        //     localStorage.setItem('curveData', JSON.stringify(data))

        //   })

        d3.json("http://localhost:8080/getLASData?uwid=US01003201370000&curveName=" + this.value).then(function (data) {
          console.log(data)

          const xScale = d3.scaleLinear().domain([0, d3.max(data.curves, function (d) { return d[0] })]).range([0, 210]); // Xaxis Scale
          const yScale = d3.scaleLinear().domain([d3.max(data.curves, function (d) { return d[1] }), d3.min(data.curves, function (d) { return d[1] })]).range([300, 0]); // Yaxis Scale

          const xAxis = d3.axisTop(xScale).ticks(5); // Xaxis 
          const yAxis = d3.axisLeft(yScale).ticks(5); // Y axis 
          const line = d3.line()
            .x(function (d) { return xScale(d[0]) })
            .y(function (d) { return yScale(d[1]) })
            .curve(d3.curveCardinal) // Cardinal graph generater
          const grp = d3.select('.mainGrp');
          const shapegrp = grp.append('g').attr('class', 'chartGrp').attr('transform', 'translate(30,160)');
          const rastergrp = grp.append('g').attr('class', 'rasterGrp').attr('transform', 'translate(0,100)');
          const grpXAxis = shapegrp.append('g').attr('class', 'axisred').attr('transform', 'translate(7,0)');
          grpXAxis.call(xAxis);
          const grpYAxis = shapegrp.append('g').attr('class', 'axisred').attr('transform', 'translate(7,0)');
          grpYAxis.call(yAxis);
          const curveColor = '#ff6600';
          // if(this.value !=='GRR'){
          //   const curveColor = '#ff6600';
          // }
          shapegrp.append("path").attr('transform', 'translate(11,2)')
            .attr("d", line(data.curves))
            .attr('class', 'lasgrp')
            .attr('fill', 'none')
            .attr('stroke-width', 1)
            .attr('stroke', data.curveColor)




          var rasterImg = rastergrp.append('foreignObject')
            .attr('width', '250')
            .attr('height', '400')
            .attr('class', 'rastergrp')
            .style('display', 'none');

          const rasterDiv = rasterImg.append('xhtml:div')
            .attr('class', 'rastergrp')
            .append('img')
            .attr('src', 'http://localhost:8080/getTiffFile?tiffFileName=us50089200010000_4629856')
            .attr('class', 'imgsize')

          // shapegrp.append('rect')
          //   .attr('width', '220')
          //   .attr('class', 'rastergrp')
          //   .attr('height', '300')
          //   .attr('fill', 'blue')
          //   .style('display', 'none');
          shapegrp.on('click', function (e) {
          })

        })
        // this.curveData = JSON.parse(localStorage.getItem('curveData'))

        // const xScale = d3.scaleLinear().domain([0, d3.max(this.points, function (d) { return d[0] })]).range([0, 210]); // Xaxis Scale
        // const yScale = d3.scaleLinear().domain([d3.max(this.points, function (d) { return d[1] }), 2000]).range([300, 0]); // Yaxis Scale

        // const xAxis = d3.axisTop(xScale); // Xaxis 
        // const yAxis = d3.axisLeft(yScale); // Y axis 
        // const line = d3.line()
        //   .x(function (d) { return xScale(d[0]) })
        //   .y(function (d) { return yScale(d[1]) })
        //   .curve(d3.curveCardinal) // Cardinal graph generater
        // const grp = d3.select('.mainGrp');
        // const shapegrp = grp.append('g').attr('class', 'chartGrp').attr('transform', 'translate(30,160)')
        // const grpXAxis = shapegrp.append('g').attr('transform', 'translate(7,0)');
        // grpXAxis.call(xAxis);
        // const grpYAxis = shapegrp.append('g').attr('transform', 'translate(7,0)');
        // grpYAxis.call(yAxis);
        // shapegrp.append("path").attr('transform', 'translate(11,2)')
        //   .attr("d", line(this.points))
        //   .attr('class', 'lasgrp')
        //   .attr('fill', 'none')
        //   .attr('stroke-width', 1)
        //   .attr('stroke', '#00AAAB')

        // shapegrp.append('rect')
        //   .attr('width', '220')
        //   .attr('class', 'rastergrp')
        //   .attr('height', '300')
        //   .attr('fill', 'blue')
        //   .style('display', 'none');
        // shapegrp.on('click', function (e) {
        // })

      })







      // .on('click',function(d){
      //     console.log('This is viajy');
      // });



    }
  }

  private async drawCurve() {

    this._http.getCrossSectionData(this.uwid, this.curveName)
      .subscribe(
      data => {
        console.log(data)

        //console.log(this.points)
        localStorage.setItem('curveData', JSON.stringify(data))

      })
    this.curveData = JSON.parse(localStorage.getItem('curveData'))
    this.points = this.curveData.curves;

    const xScale = d3.scaleLinear().domain([0, d3.max(this.points, function (d) { return d[0] })]).range([0, 210]); // Xaxis Scale
    const yScale = d3.scaleLinear().domain([d3.max(this.points, function (d) { return d[1] }), d3.min(this.points, function (d) { return d[1] })]).range([300, 0]); // Yaxis Scale

    const xAxis = d3.axisTop(xScale).ticks(5); // Xaxis 
    const yAxis = d3.axisLeft(yScale).ticks(5); // Y axis 
    const line = d3.line()
      .x(function (d) { return xScale(d[0]) })
      .y(function (d) { return yScale(d[1]) })
      .curve(d3.curveCardinal) // Cardinal graph generater
    const grp = d3.select('.mainGrp');
    const shapegrp = grp.append('g').attr('class', 'chartGrp').style('display', 'none').attr('transform', 'translate(30,160)');
    const rastergrp = grp.append('g').attr('class', 'rasterGrp').attr('transform', 'translate(0,100)');
    const grpXAxis = shapegrp.append('g').attr('class', 'axisred').attr('transform', 'translate(7,0)');
    grpXAxis.call(xAxis);
    const grpYAxis = shapegrp.append('g').attr('class', 'axisred').attr('transform', 'translate(7,0)');
    grpYAxis.call(yAxis);
    shapegrp.append("path").attr('class', 'line').attr('transform', 'translate(11,2)')
      .attr("d", line(this.points))
      .attr('class', 'lasgrp')
      .attr('fill', 'none')
      .attr('stroke-width', 1)
      .attr('stroke', '#3496f7')
    //.attr('stroke', function(){ return "hsl (" +Math.random() *360 +",100%,50%)" })
          document.querySelector('.lasdropdown').selectedIndex = "8";

    var rasterImg = rastergrp.append('foreignObject')
      .attr('width', '250')
      .attr('height', '500')
      .attr('class', 'rastergrp ');
    const rasterDiv = rasterImg.append('xhtml:div')
      .attr('class', 'imggrp scrollbar scrollbar-success')
      .append('img')
      .attr('src', 'http://localhost:8080/getTiffFile?tiffFileName=us50089200010000_4629856')
      .attr('class', 'imgsize')



    // shapegrp.append('rect')
    //   .attr('width', '220')
    //   .attr('class', 'rastergrp')
    //   .attr('height', '300')
    //   .attr('fill', 'blue')
    //   .style('display', 'none');
    shapegrp.on('click', function (e) {
    })

  }







  // private drawAxisandPath(data) {
  //   const points: any[] = [];

  //   const xScale = d3.scaleLinear().domain([0, d3.max(points, function (d) { return d[0] })]).range([0, 210]); // Xaxis Scale
  //   const yScale = d3.scaleLinear().domain([d3.max(points, function (d) { return d[1] }), 2000]).range([300, 0]); // Yaxis Scale

  //   const xAxis = d3.axisTop(xScale); // Xaxis 
  //   const yAxis = d3.axisLeft(yScale); // Y axis 
  //   const line = d3.line()
  //     .x(function (d) { return xScale(d[0]) })
  //     .y(function (d) { return yScale(d[1]) })
  //     .curve(d3.curveCardinal) // Cardinal graph generater
  //   const grp = d3.select('mainGrp');
  //   const shapegrp = grp.append('g').attr('transform', 'translate(30,160)')
  //   const grpXAxis = shapegrp.append('g').attr('transform', 'translate(7,0)');
  //   grpXAxis.call(xAxis);
  //   const grpYAxis = shapegrp.append('g').attr('transform', 'translate(7,0)');
  //   grpYAxis.call(yAxis);
  //   shapegrp.append("path").attr('transform', 'translate(11,2)')
  //     .attr("d", line(points))
  //     .attr('class', 'lasgrp' + t)
  //     .attr('fill', 'none')
  //     .attr('stroke-width', 1)
  //     .attr('stroke', 'blue')
  //   // .on('click',function(d){
  //   //     console.log('This is viajy');
  //   // });
  //   shapegrp.append('rect')
  //     .attr('width', '220')
  //     .attr('class', 'rastergrp' + t)
  //     .attr('height', '300')
  //     .attr('fill', 'blue')
  //     .style('display', 'none');
  //   shapegrp.on('click', function (e) {
  //   })
  // }



}
